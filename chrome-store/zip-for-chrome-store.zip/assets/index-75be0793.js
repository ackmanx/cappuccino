var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
(function polyfill() {
  const relList = document.createElement("link").relList;
  if (relList && relList.supports && relList.supports("modulepreload")) {
    return;
  }
  for (const link of document.querySelectorAll('link[rel="modulepreload"]')) {
    processPreload(link);
  }
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== "childList") {
        continue;
      }
      for (const node of mutation.addedNodes) {
        if (node.tagName === "LINK" && node.rel === "modulepreload")
          processPreload(node);
      }
    }
  }).observe(document, { childList: true, subtree: true });
  function getFetchOpts(link) {
    const fetchOpts = {};
    if (link.integrity)
      fetchOpts.integrity = link.integrity;
    if (link.referrerPolicy)
      fetchOpts.referrerPolicy = link.referrerPolicy;
    if (link.crossOrigin === "use-credentials")
      fetchOpts.credentials = "include";
    else if (link.crossOrigin === "anonymous")
      fetchOpts.credentials = "omit";
    else
      fetchOpts.credentials = "same-origin";
    return fetchOpts;
  }
  function processPreload(link) {
    if (link.ep)
      return;
    link.ep = true;
    const fetchOpts = getFetchOpts(link);
    fetch(link.href, fetchOpts);
  }
})();
const index = "";
function noop() {
}
const identity = (x) => x;
function assign(tar, src) {
  for (const k in src)
    tar[k] = src[k];
  return (
    /** @type {T & S} */
    tar
  );
}
function run(fn) {
  return fn();
}
function blank_object() {
  return /* @__PURE__ */ Object.create(null);
}
function run_all(fns) {
  fns.forEach(run);
}
function is_function(thing) {
  return typeof thing === "function";
}
function safe_not_equal(a, b) {
  return a != a ? b == b : a !== b || a && typeof a === "object" || typeof a === "function";
}
let src_url_equal_anchor;
function src_url_equal(element_src, url) {
  if (element_src === url)
    return true;
  if (!src_url_equal_anchor) {
    src_url_equal_anchor = document.createElement("a");
  }
  src_url_equal_anchor.href = url;
  return element_src === src_url_equal_anchor.href;
}
function is_empty(obj) {
  return Object.keys(obj).length === 0;
}
function subscribe(store, ...callbacks) {
  if (store == null) {
    for (const callback of callbacks) {
      callback(void 0);
    }
    return noop;
  }
  const unsub = store.subscribe(...callbacks);
  return unsub.unsubscribe ? () => unsub.unsubscribe() : unsub;
}
function component_subscribe(component, store, callback) {
  component.$$.on_destroy.push(subscribe(store, callback));
}
function create_slot(definition, ctx, $$scope, fn) {
  if (definition) {
    const slot_ctx = get_slot_context(definition, ctx, $$scope, fn);
    return definition[0](slot_ctx);
  }
}
function get_slot_context(definition, ctx, $$scope, fn) {
  return definition[1] && fn ? assign($$scope.ctx.slice(), definition[1](fn(ctx))) : $$scope.ctx;
}
function get_slot_changes(definition, $$scope, dirty, fn) {
  if (definition[2] && fn) {
    const lets = definition[2](fn(dirty));
    if ($$scope.dirty === void 0) {
      return lets;
    }
    if (typeof lets === "object") {
      const merged = [];
      const len = Math.max($$scope.dirty.length, lets.length);
      for (let i = 0; i < len; i += 1) {
        merged[i] = $$scope.dirty[i] | lets[i];
      }
      return merged;
    }
    return $$scope.dirty | lets;
  }
  return $$scope.dirty;
}
function update_slot_base(slot, slot_definition, ctx, $$scope, slot_changes, get_slot_context_fn) {
  if (slot_changes) {
    const slot_context = get_slot_context(slot_definition, ctx, $$scope, get_slot_context_fn);
    slot.p(slot_context, slot_changes);
  }
}
function get_all_dirty_from_scope($$scope) {
  if ($$scope.ctx.length > 32) {
    const dirty = [];
    const length = $$scope.ctx.length / 32;
    for (let i = 0; i < length; i++) {
      dirty[i] = -1;
    }
    return dirty;
  }
  return -1;
}
function set_store_value(store, ret, value) {
  store.set(value);
  return ret;
}
function action_destroyer(action_result) {
  return action_result && is_function(action_result.destroy) ? action_result.destroy : noop;
}
const is_client = typeof window !== "undefined";
let now = is_client ? () => window.performance.now() : () => Date.now();
let raf = is_client ? (cb) => requestAnimationFrame(cb) : noop;
const tasks = /* @__PURE__ */ new Set();
function run_tasks(now2) {
  tasks.forEach((task) => {
    if (!task.c(now2)) {
      tasks.delete(task);
      task.f();
    }
  });
  if (tasks.size !== 0)
    raf(run_tasks);
}
function loop(callback) {
  let task;
  if (tasks.size === 0)
    raf(run_tasks);
  return {
    promise: new Promise((fulfill) => {
      tasks.add(task = { c: callback, f: fulfill });
    }),
    abort() {
      tasks.delete(task);
    }
  };
}
function append(target, node) {
  target.appendChild(node);
}
function get_root_for_style(node) {
  if (!node)
    return document;
  const root = node.getRootNode ? node.getRootNode() : node.ownerDocument;
  if (root && /** @type {ShadowRoot} */
  root.host) {
    return (
      /** @type {ShadowRoot} */
      root
    );
  }
  return node.ownerDocument;
}
function append_empty_stylesheet(node) {
  const style_element = element("style");
  style_element.textContent = "/* empty */";
  append_stylesheet(get_root_for_style(node), style_element);
  return style_element.sheet;
}
function append_stylesheet(node, style) {
  append(
    /** @type {Document} */
    node.head || node,
    style
  );
  return style.sheet;
}
function insert(target, node, anchor) {
  target.insertBefore(node, anchor || null);
}
function detach(node) {
  if (node.parentNode) {
    node.parentNode.removeChild(node);
  }
}
function destroy_each(iterations, detaching) {
  for (let i = 0; i < iterations.length; i += 1) {
    if (iterations[i])
      iterations[i].d(detaching);
  }
}
function element(name) {
  return document.createElement(name);
}
function svg_element(name) {
  return document.createElementNS("http://www.w3.org/2000/svg", name);
}
function text(data) {
  return document.createTextNode(data);
}
function space() {
  return text(" ");
}
function empty() {
  return text("");
}
function listen(node, event, handler, options) {
  node.addEventListener(event, handler, options);
  return () => node.removeEventListener(event, handler, options);
}
function attr(node, attribute, value) {
  if (value == null)
    node.removeAttribute(attribute);
  else if (node.getAttribute(attribute) !== value)
    node.setAttribute(attribute, value);
}
function init_binding_group(group) {
  let _inputs;
  return {
    /* push */
    p(...inputs) {
      _inputs = inputs;
      _inputs.forEach((input) => group.push(input));
    },
    /* remove */
    r() {
      _inputs.forEach((input) => group.splice(group.indexOf(input), 1));
    }
  };
}
function children(element2) {
  return Array.from(element2.childNodes);
}
function set_data(text2, data) {
  data = "" + data;
  if (text2.data === data)
    return;
  text2.data = /** @type {string} */
  data;
}
function set_input_value(input, value) {
  input.value = value == null ? "" : value;
}
function set_style(node, key, value, important) {
  if (value == null) {
    node.style.removeProperty(key);
  } else {
    node.style.setProperty(key, value, important ? "important" : "");
  }
}
function toggle_class(element2, name, toggle) {
  element2.classList.toggle(name, !!toggle);
}
function custom_event(type, detail, { bubbles = false, cancelable = false } = {}) {
  return new CustomEvent(type, { detail, bubbles, cancelable });
}
const managed_styles = /* @__PURE__ */ new Map();
let active = 0;
function hash(str) {
  let hash2 = 5381;
  let i = str.length;
  while (i--)
    hash2 = (hash2 << 5) - hash2 ^ str.charCodeAt(i);
  return hash2 >>> 0;
}
function create_style_information(doc, node) {
  const info = { stylesheet: append_empty_stylesheet(node), rules: {} };
  managed_styles.set(doc, info);
  return info;
}
function create_rule(node, a, b, duration, delay, ease, fn, uid = 0) {
  const step = 16.666 / duration;
  let keyframes = "{\n";
  for (let p = 0; p <= 1; p += step) {
    const t = a + (b - a) * ease(p);
    keyframes += p * 100 + `%{${fn(t, 1 - t)}}
`;
  }
  const rule = keyframes + `100% {${fn(b, 1 - b)}}
}`;
  const name = `__svelte_${hash(rule)}_${uid}`;
  const doc = get_root_for_style(node);
  const { stylesheet, rules } = managed_styles.get(doc) || create_style_information(doc, node);
  if (!rules[name]) {
    rules[name] = true;
    stylesheet.insertRule(`@keyframes ${name} ${rule}`, stylesheet.cssRules.length);
  }
  const animation = node.style.animation || "";
  node.style.animation = `${animation ? `${animation}, ` : ""}${name} ${duration}ms linear ${delay}ms 1 both`;
  active += 1;
  return name;
}
function delete_rule(node, name) {
  const previous = (node.style.animation || "").split(", ");
  const next = previous.filter(
    name ? (anim) => anim.indexOf(name) < 0 : (anim) => anim.indexOf("__svelte") === -1
    // remove all Svelte animations
  );
  const deleted = previous.length - next.length;
  if (deleted) {
    node.style.animation = next.join(", ");
    active -= deleted;
    if (!active)
      clear_rules();
  }
}
function clear_rules() {
  raf(() => {
    if (active)
      return;
    managed_styles.forEach((info) => {
      const { ownerNode } = info.stylesheet;
      if (ownerNode)
        detach(ownerNode);
    });
    managed_styles.clear();
  });
}
let current_component;
function set_current_component(component) {
  current_component = component;
}
function get_current_component() {
  if (!current_component)
    throw new Error("Function called outside component initialization");
  return current_component;
}
function onMount(fn) {
  get_current_component().$$.on_mount.push(fn);
}
function setContext(key, context) {
  get_current_component().$$.context.set(key, context);
  return context;
}
function getContext(key) {
  return get_current_component().$$.context.get(key);
}
const dirty_components = [];
const binding_callbacks = [];
let render_callbacks = [];
const flush_callbacks = [];
const resolved_promise = /* @__PURE__ */ Promise.resolve();
let update_scheduled = false;
function schedule_update() {
  if (!update_scheduled) {
    update_scheduled = true;
    resolved_promise.then(flush);
  }
}
function add_render_callback(fn) {
  render_callbacks.push(fn);
}
const seen_callbacks = /* @__PURE__ */ new Set();
let flushidx = 0;
function flush() {
  if (flushidx !== 0) {
    return;
  }
  const saved_component = current_component;
  do {
    try {
      while (flushidx < dirty_components.length) {
        const component = dirty_components[flushidx];
        flushidx++;
        set_current_component(component);
        update(component.$$);
      }
    } catch (e) {
      dirty_components.length = 0;
      flushidx = 0;
      throw e;
    }
    set_current_component(null);
    dirty_components.length = 0;
    flushidx = 0;
    while (binding_callbacks.length)
      binding_callbacks.pop()();
    for (let i = 0; i < render_callbacks.length; i += 1) {
      const callback = render_callbacks[i];
      if (!seen_callbacks.has(callback)) {
        seen_callbacks.add(callback);
        callback();
      }
    }
    render_callbacks.length = 0;
  } while (dirty_components.length);
  while (flush_callbacks.length) {
    flush_callbacks.pop()();
  }
  update_scheduled = false;
  seen_callbacks.clear();
  set_current_component(saved_component);
}
function update($$) {
  if ($$.fragment !== null) {
    $$.update();
    run_all($$.before_update);
    const dirty = $$.dirty;
    $$.dirty = [-1];
    $$.fragment && $$.fragment.p($$.ctx, dirty);
    $$.after_update.forEach(add_render_callback);
  }
}
function flush_render_callbacks(fns) {
  const filtered = [];
  const targets = [];
  render_callbacks.forEach((c) => fns.indexOf(c) === -1 ? filtered.push(c) : targets.push(c));
  targets.forEach((c) => c());
  render_callbacks = filtered;
}
let promise;
function wait() {
  if (!promise) {
    promise = Promise.resolve();
    promise.then(() => {
      promise = null;
    });
  }
  return promise;
}
function dispatch(node, direction, kind) {
  node.dispatchEvent(custom_event(`${direction ? "intro" : "outro"}${kind}`));
}
const outroing = /* @__PURE__ */ new Set();
let outros;
function group_outros() {
  outros = {
    r: 0,
    c: [],
    p: outros
    // parent group
  };
}
function check_outros() {
  if (!outros.r) {
    run_all(outros.c);
  }
  outros = outros.p;
}
function transition_in(block, local) {
  if (block && block.i) {
    outroing.delete(block);
    block.i(local);
  }
}
function transition_out(block, local, detach2, callback) {
  if (block && block.o) {
    if (outroing.has(block))
      return;
    outroing.add(block);
    outros.c.push(() => {
      outroing.delete(block);
      if (callback) {
        if (detach2)
          block.d(1);
        callback();
      }
    });
    block.o(local);
  } else if (callback) {
    callback();
  }
}
const null_transition = { duration: 0 };
function create_bidirectional_transition(node, fn, params, intro) {
  const options = { direction: "both" };
  let config = fn(node, params, options);
  let t = intro ? 0 : 1;
  let running_program = null;
  let pending_program = null;
  let animation_name = null;
  let original_inert_value;
  function clear_animation() {
    if (animation_name)
      delete_rule(node, animation_name);
  }
  function init2(program, duration) {
    const d = (
      /** @type {Program['d']} */
      program.b - t
    );
    duration *= Math.abs(d);
    return {
      a: t,
      b: program.b,
      d,
      duration,
      start: program.start,
      end: program.start + duration,
      group: program.group
    };
  }
  function go(b) {
    const {
      delay = 0,
      duration = 300,
      easing = identity,
      tick = noop,
      css
    } = config || null_transition;
    const program = {
      start: now() + delay,
      b
    };
    if (!b) {
      program.group = outros;
      outros.r += 1;
    }
    if ("inert" in node) {
      if (b) {
        if (original_inert_value !== void 0) {
          node.inert = original_inert_value;
        }
      } else {
        original_inert_value = /** @type {HTMLElement} */
        node.inert;
        node.inert = true;
      }
    }
    if (running_program || pending_program) {
      pending_program = program;
    } else {
      if (css) {
        clear_animation();
        animation_name = create_rule(node, t, b, duration, delay, easing, css);
      }
      if (b)
        tick(0, 1);
      running_program = init2(program, duration);
      add_render_callback(() => dispatch(node, b, "start"));
      loop((now2) => {
        if (pending_program && now2 > pending_program.start) {
          running_program = init2(pending_program, duration);
          pending_program = null;
          dispatch(node, running_program.b, "start");
          if (css) {
            clear_animation();
            animation_name = create_rule(
              node,
              t,
              running_program.b,
              running_program.duration,
              0,
              easing,
              config.css
            );
          }
        }
        if (running_program) {
          if (now2 >= running_program.end) {
            tick(t = running_program.b, 1 - t);
            dispatch(node, running_program.b, "end");
            if (!pending_program) {
              if (running_program.b) {
                clear_animation();
              } else {
                if (!--running_program.group.r)
                  run_all(running_program.group.c);
              }
            }
            running_program = null;
          } else if (now2 >= running_program.start) {
            const p = now2 - running_program.start;
            t = running_program.a + running_program.d * easing(p / running_program.duration);
            tick(t, 1 - t);
          }
        }
        return !!(running_program || pending_program);
      });
    }
  }
  return {
    run(b) {
      if (is_function(config)) {
        wait().then(() => {
          const opts = { direction: b ? "in" : "out" };
          config = config(opts);
          go(b);
        });
      } else {
        go(b);
      }
    },
    end() {
      clear_animation();
      running_program = pending_program = null;
    }
  };
}
function ensure_array_like(array_like_or_iterator) {
  return (array_like_or_iterator == null ? void 0 : array_like_or_iterator.length) !== void 0 ? array_like_or_iterator : Array.from(array_like_or_iterator);
}
function create_component(block) {
  block && block.c();
}
function mount_component(component, target, anchor) {
  const { fragment, after_update } = component.$$;
  fragment && fragment.m(target, anchor);
  add_render_callback(() => {
    const new_on_destroy = component.$$.on_mount.map(run).filter(is_function);
    if (component.$$.on_destroy) {
      component.$$.on_destroy.push(...new_on_destroy);
    } else {
      run_all(new_on_destroy);
    }
    component.$$.on_mount = [];
  });
  after_update.forEach(add_render_callback);
}
function destroy_component(component, detaching) {
  const $$ = component.$$;
  if ($$.fragment !== null) {
    flush_render_callbacks($$.after_update);
    run_all($$.on_destroy);
    $$.fragment && $$.fragment.d(detaching);
    $$.on_destroy = $$.fragment = null;
    $$.ctx = [];
  }
}
function make_dirty(component, i) {
  if (component.$$.dirty[0] === -1) {
    dirty_components.push(component);
    schedule_update();
    component.$$.dirty.fill(0);
  }
  component.$$.dirty[i / 31 | 0] |= 1 << i % 31;
}
function init(component, options, instance2, create_fragment2, not_equal, props, append_styles = null, dirty = [-1]) {
  const parent_component = current_component;
  set_current_component(component);
  const $$ = component.$$ = {
    fragment: null,
    ctx: [],
    // state
    props,
    update: noop,
    not_equal,
    bound: blank_object(),
    // lifecycle
    on_mount: [],
    on_destroy: [],
    on_disconnect: [],
    before_update: [],
    after_update: [],
    context: new Map(options.context || (parent_component ? parent_component.$$.context : [])),
    // everything else
    callbacks: blank_object(),
    dirty,
    skip_bound: false,
    root: options.target || parent_component.$$.root
  };
  append_styles && append_styles($$.root);
  let ready = false;
  $$.ctx = instance2 ? instance2(component, options.props || {}, (i, ret, ...rest) => {
    const value = rest.length ? rest[0] : ret;
    if ($$.ctx && not_equal($$.ctx[i], $$.ctx[i] = value)) {
      if (!$$.skip_bound && $$.bound[i])
        $$.bound[i](value);
      if (ready)
        make_dirty(component, i);
    }
    return ret;
  }) : [];
  $$.update();
  ready = true;
  run_all($$.before_update);
  $$.fragment = create_fragment2 ? create_fragment2($$.ctx) : false;
  if (options.target) {
    if (options.hydrate) {
      const nodes = children(options.target);
      $$.fragment && $$.fragment.l(nodes);
      nodes.forEach(detach);
    } else {
      $$.fragment && $$.fragment.c();
    }
    if (options.intro)
      transition_in(component.$$.fragment);
    mount_component(component, options.target, options.anchor);
    flush();
  }
  set_current_component(parent_component);
}
class SvelteComponent {
  constructor() {
    /**
     * ### PRIVATE API
     *
     * Do not use, may change at any time
     *
     * @type {any}
     */
    __publicField(this, "$$");
    /**
     * ### PRIVATE API
     *
     * Do not use, may change at any time
     *
     * @type {any}
     */
    __publicField(this, "$$set");
  }
  /** @returns {void} */
  $destroy() {
    destroy_component(this, 1);
    this.$destroy = noop;
  }
  /**
   * @template {Extract<keyof Events, string>} K
   * @param {K} type
   * @param {((e: Events[K]) => void) | null | undefined} callback
   * @returns {() => void}
   */
  $on(type, callback) {
    if (!is_function(callback)) {
      return noop;
    }
    const callbacks = this.$$.callbacks[type] || (this.$$.callbacks[type] = []);
    callbacks.push(callback);
    return () => {
      const index2 = callbacks.indexOf(callback);
      if (index2 !== -1)
        callbacks.splice(index2, 1);
    };
  }
  /**
   * @param {Partial<Props>} props
   * @returns {void}
   */
  $set(props) {
    if (this.$$set && !is_empty(props)) {
      this.$$.skip_bound = true;
      this.$$set(props);
      this.$$.skip_bound = false;
    }
  }
}
const PUBLIC_VERSION = "4";
if (typeof window !== "undefined")
  (window.__svelte || (window.__svelte = { v: /* @__PURE__ */ new Set() })).v.add(PUBLIC_VERSION);
const subscriber_queue = [];
function writable(value, start = noop) {
  let stop;
  const subscribers = /* @__PURE__ */ new Set();
  function set(new_value) {
    if (safe_not_equal(value, new_value)) {
      value = new_value;
      if (stop) {
        const run_queue = !subscriber_queue.length;
        for (const subscriber of subscribers) {
          subscriber[1]();
          subscriber_queue.push(subscriber, value);
        }
        if (run_queue) {
          for (let i = 0; i < subscriber_queue.length; i += 2) {
            subscriber_queue[i][0](subscriber_queue[i + 1]);
          }
          subscriber_queue.length = 0;
        }
      }
    }
  }
  function update2(fn) {
    set(fn(value));
  }
  function subscribe2(run2, invalidate = noop) {
    const subscriber = [run2, invalidate];
    subscribers.add(subscriber);
    if (subscribers.size === 1) {
      stop = start(set, update2) || noop;
    }
    run2(value);
    return () => {
      subscribers.delete(subscriber);
      if (subscribers.size === 0 && stop) {
        stop();
        stop = null;
      }
    };
  }
  return { set, update: update2, subscribe: subscribe2 };
}
function setLayerConfig() {
  setContext("layerConfig", writable({ activate: false, type: "drawer", subtype: "tab" }));
}
function getLayerConfig() {
  return getContext("layerConfig");
}
function getSettings() {
  return getContext("settings");
}
function setSettings() {
  const settings = localStorage.getItem("settings");
  if (settings) {
    setContext("settings", writable(JSON.parse(settings)));
  } else {
    setContext("settings", writable({ editable: false, color: "#CE7432", defaultTab: 0 }));
  }
}
function getContextByDraggableList(key) {
  return getContext(key);
}
function setContextByDraggableList(key) {
  setContext(
    key,
    writable(structuredClone({ key, grabbed: -1, draggedOver: -1, isDragEnabled: false }))
  );
}
const SettingsIcon_svelte_svelte_type_style_lang = "";
function create_fragment$r(ctx) {
  let svg;
  let g;
  let path0;
  let path1;
  let path2;
  return {
    c() {
      svg = svg_element("svg");
      g = svg_element("g");
      path0 = svg_element("path");
      path1 = svg_element("path");
      path2 = svg_element("path");
      attr(path0, "d", "M419.844 70.8125C414.321 70.8125 409.844 75.2897 409.844 80.8125L409.844 185.031C390.423 191.099 371.482 199.028 353.125 208.656L279.344 134.875C275.439 130.97 269.124 130.97 265.219 134.875L134.875 265.219C130.969 269.125 130.968 275.439 134.875 279.344L208.344 352.781C198.578 371.213 190.551 390.267 184.375 409.844L80.8125 409.844C75.2897 409.844 70.8125 414.321 70.8125 419.844L70.8125 604.156C70.8125 609.679 75.2897 614.156 80.8125 614.156L183.812 614.156C189.92 633.913 197.929 653.177 207.719 671.844L134.875 744.688C130.969 748.593 130.969 754.907 134.875 758.813L265.219 889.125C269.125 893.03 275.439 893.031 279.344 889.125L351.812 816.625C370.556 826.559 389.939 834.69 409.844 840.906L409.844 943.188C409.844 948.71 414.321 953.188 419.844 953.188L604.156 953.188C609.679 953.188 614.156 948.71 614.156 943.188L614.156 836.625C614.156 833.973 613.094 831.438 611.219 829.563L519.062 737.406C517.187 735.531 514.652 734.469 512 734.469C389.13 734.469 289.531 634.87 289.531 512C289.531 389.13 389.13 289.531 512 289.531C634.549 289.531 733.984 388.635 734.438 511.156C734.447 513.796 735.509 516.321 737.375 518.188L830.406 611.219C832.282 613.094 834.817 614.156 837.469 614.156L943.188 614.156C948.71 614.156 953.188 609.679 953.188 604.156L953.188 419.844C953.188 414.321 948.71 409.844 943.188 409.844L839.625 409.844C833.449 390.267 825.422 371.214 815.656 352.781L889.125 279.344C893.031 275.439 893.03 269.125 889.125 265.219L758.812 134.875C754.907 130.969 748.593 130.969 744.688 134.875L670.906 208.656C652.553 199.03 633.608 191.105 614.156 185.031L614.156 80.8125C614.156 75.2897 609.679 70.8125 604.156 70.8125C602.716 70.8125 421.284 70.8125 419.844 70.8125ZM429.844 90.8125C447.595 90.8125 576.405 90.8125 594.156 90.8125L594.156 192.344C594.156 196.804 597.119 200.739 601.406 201.969C624.336 208.548 646.571 217.819 667.969 229.625C671.869 231.777 676.726 231.087 679.875 227.938L751.75 156.063L867.938 272.281L796.344 343.844C793.182 347.004 792.48 351.876 794.656 355.781C806.61 377.233 816.061 399.577 822.75 422.625C823.99 426.898 827.894 429.844 832.344 429.844L933.188 429.844L933.188 594.156L841.594 594.156L754.312 506.875C751.569 375.298 644.151 269.531 512 269.531C378.085 269.531 269.531 378.085 269.531 512C269.531 644.499 375.822 752.113 507.781 754.375L594.156 840.75L594.156 933.188L429.844 933.188L429.844 833.594C429.844 829.133 426.881 825.199 422.594 823.969C399.237 817.267 376.594 807.778 354.844 795.656C354.836 795.652 354.82 795.661 354.812 795.656C354.674 795.58 354.548 795.476 354.406 795.406C353.643 795.156 353.443 795.117 352.969 794.969C352.518 794.824 352.086 794.609 351.625 794.531C351.802 794.575 352.28 794.773 352.5 794.844C352.201 794.755 351.656 794.58 351.438 794.531C350.555 794.399 349.66 794.366 348.781 794.469C348.761 794.471 348.704 794.467 348.688 794.469C348.604 794.479 348.521 794.487 348.438 794.5C348.428 794.501 348.416 794.498 348.406 794.5C346.361 794.818 344.416 795.771 342.875 797.313L272.281 867.938L156.062 751.75L227 680.813C230.149 677.663 230.838 672.806 228.688 668.906C216.711 647.191 207.336 624.655 200.75 601.438C199.53 597.135 195.597 594.156 191.125 594.156L90.8125 594.156L90.8125 429.844L191.656 429.844C196.106 429.844 200.01 426.898 201.25 422.625C207.939 399.577 217.39 377.231 229.344 355.781C231.52 351.876 230.818 347.004 227.656 343.844L156.062 272.281L272.281 156.063L344.156 227.938C347.305 231.087 352.163 231.776 356.062 229.625C377.479 217.811 399.702 208.538 422.594 201.969C426.881 200.738 429.844 196.804 429.844 192.344L429.844 90.8125ZM348.781 794.469C348.938 794.448 348.994 794.421 349.562 794.375C349.499 794.378 349.475 794.372 349.406 794.375C348.862 794.428 348.921 794.452 348.781 794.469ZM350.094 794.406C350.58 794.405 351 794.418 351.406 794.5C350.971 794.404 350.498 794.402 350.094 794.406Z");
      attr(path0, "fill", "#000000");
      attr(path0, "fill-rule", "nonzero");
      attr(path0, "opacity", "1");
      attr(path0, "stroke", "none");
      attr(path0, "class", "svelte-nzgmqd");
      attr(path1, "d", "M490.438 336.875C472.886 337.351 464.428 358.616 476.844 371.031C494.577 388.764 526.796 421.015 547.75 441.969C541.912 465.87 534.028 498.178 528.125 522.344C503.944 528.253 471.624 536.158 447.719 542C426.765 521.046 394.546 488.796 376.812 471.063C364.397 458.647 343.131 467.104 342.656 484.656C341.477 528.205 353.219 579.907 390.281 616.969C437.901 664.589 514.729 683.092 573.969 664.75C649.168 736.979 786.965 869.363 857.969 937.563C865.822 945.105 878.269 944.981 885.969 937.281C900.243 923.007 928.788 894.462 943.062 880.188C950.762 872.488 950.918 860.041 943.375 852.188C875.167 781.175 742.761 643.325 670.531 568.125C688.892 508.774 670.239 431.989 622.75 384.5C585.659 347.409 533.943 335.696 490.438 336.875Z");
      attr(path1, "fill", "#131313");
      attr(path1, "fill-rule", "nonzero");
      attr(path1, "opacity", "1");
      attr(path1, "stroke", "none");
      attr(path1, "class", "svelte-nzgmqd");
      attr(path2, "d", "M362.656 485.197C361.576 525.093 372.608 571.014 404.422 602.828C449.796 648.202 526.839 663.702 578.897 641.773L871.838 923.143L928.936 866.045L647.548 573.086C669.464 521.028 653.987 443.995 608.621 398.629C576.806 366.814 530.869 355.8 490.972 356.882L569.875 435.784L544.689 538.896L441.559 564.1L362.656 485.197Z");
      attr(path2, "fill", "#131313");
      attr(path2, "fill-rule", "nonzero");
      attr(path2, "opacity", "1");
      attr(path2, "stroke", "none");
      attr(path2, "class", "svelte-nzgmqd");
      attr(g, "id", "Layer-1");
      attr(svg, "height", "100%");
      attr(svg, "viewBox", "0 0 1024 1024");
      attr(svg, "width", "30");
      attr(svg, "xml:space", "preserve");
      attr(svg, "xmlns", "http://www.w3.org/2000/svg");
    },
    m(target, anchor) {
      insert(target, svg, anchor);
      append(svg, g);
      append(g, path0);
      append(g, path1);
      append(g, path2);
    },
    p: noop,
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(svg);
      }
    }
  };
}
class SettingsIcon extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, null, create_fragment$r, safe_not_equal, {});
  }
}
const Button_svelte_svelte_type_style_lang = "";
function create_fragment$q(ctx) {
  let button;
  let current;
  let mounted;
  let dispose;
  const default_slot_template = (
    /*#slots*/
    ctx[3].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[2],
    null
  );
  return {
    c() {
      button = element("button");
      if (default_slot)
        default_slot.c();
      attr(button, "class", "svelte-759i3d");
      toggle_class(
        button,
        "primary",
        /*variant*/
        ctx[0] === "primary"
      );
      toggle_class(
        button,
        "secondary",
        /*variant*/
        ctx[0] === "secondary"
      );
    },
    m(target, anchor) {
      insert(target, button, anchor);
      if (default_slot) {
        default_slot.m(button, null);
      }
      current = true;
      if (!mounted) {
        dispose = listen(button, "click", function() {
          if (is_function(
            /*onClick*/
            ctx[1]
          ))
            ctx[1].apply(this, arguments);
        });
        mounted = true;
      }
    },
    p(new_ctx, [dirty]) {
      ctx = new_ctx;
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        4)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx,
            /*$$scope*/
            ctx[2],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx[2]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx[2],
              dirty,
              null
            ),
            null
          );
        }
      }
      if (!current || dirty & /*variant*/
      1) {
        toggle_class(
          button,
          "primary",
          /*variant*/
          ctx[0] === "primary"
        );
      }
      if (!current || dirty & /*variant*/
      1) {
        toggle_class(
          button,
          "secondary",
          /*variant*/
          ctx[0] === "secondary"
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(button);
      }
      if (default_slot)
        default_slot.d(detaching);
      mounted = false;
      dispose();
    }
  };
}
function instance$l($$self, $$props, $$invalidate) {
  let { $$slots: slots = {}, $$scope } = $$props;
  let { variant = "primary" } = $$props;
  let { onClick = () => {
  } } = $$props;
  $$self.$$set = ($$props2) => {
    if ("variant" in $$props2)
      $$invalidate(0, variant = $$props2.variant);
    if ("onClick" in $$props2)
      $$invalidate(1, onClick = $$props2.onClick);
    if ("$$scope" in $$props2)
      $$invalidate(2, $$scope = $$props2.$$scope);
  };
  return [variant, onClick, $$scope, slots];
}
class Button extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$l, create_fragment$q, safe_not_equal, { variant: 0, onClick: 1 });
  }
}
const AppHeader_svelte_svelte_type_style_lang = "";
function create_default_slot$9(ctx) {
  let settingsicon;
  let current;
  settingsicon = new SettingsIcon({});
  return {
    c() {
      create_component(settingsicon.$$.fragment);
    },
    m(target, anchor) {
      mount_component(settingsicon, target, anchor);
      current = true;
    },
    i(local) {
      if (current)
        return;
      transition_in(settingsicon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(settingsicon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(settingsicon, detaching);
    }
  };
}
function create_fragment$p(ctx) {
  let component;
  let img;
  let img_src_value;
  let t0;
  let input;
  let t1;
  let button;
  let div;
  let current;
  button = new Button({
    props: {
      onClick: (
        /*openSettingsDrawer*/
        ctx[1]
      ),
      $$slots: { default: [create_default_slot$9] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      component = element("component");
      img = element("img");
      t0 = space();
      input = element("input");
      t1 = space();
      div = element("div");
      create_component(button.$$.fragment);
      if (!src_url_equal(img.src, img_src_value = "logo.svg"))
        attr(img, "src", img_src_value);
      attr(img, "alt", "cappuccino logo");
      attr(img, "class", "svelte-bc1pb0");
      attr(input, "class", "svelte-bc1pb0");
      set_style(div, "display", "contents");
      set_style(div, "--color-accent", "transparent");
      attr(component, "class", "svelte-bc1pb0");
    },
    m(target, anchor) {
      insert(target, component, anchor);
      append(component, img);
      append(component, t0);
      append(component, input);
      append(component, t1);
      append(component, div);
      mount_component(button, div, null);
      current = true;
    },
    p(ctx2, [dirty]) {
      const button_changes = {};
      if (dirty & /*$$scope*/
      8) {
        button_changes.$$scope = { dirty, ctx: ctx2 };
      }
      button.$set(button_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(button.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(button.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(component);
      }
      destroy_component(button);
    }
  };
}
function instance$k($$self, $$props, $$invalidate) {
  let $layerConfig;
  const layerConfig = getLayerConfig();
  component_subscribe($$self, layerConfig, (value) => $$invalidate(2, $layerConfig = value));
  function openSettingsDrawer() {
    set_store_value(
      layerConfig,
      $layerConfig = {
        activate: true,
        type: "drawer",
        subtype: "setting"
      },
      $layerConfig
    );
  }
  return [layerConfig, openSettingsDrawer];
}
class AppHeader extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$k, create_fragment$p, safe_not_equal, {});
  }
}
const EditIcon_svelte_svelte_type_style_lang = "";
function create_fragment$o(ctx) {
  let svg;
  let path0;
  let path1;
  let path2;
  let path3;
  let path4;
  let path5;
  return {
    c() {
      svg = svg_element("svg");
      path0 = svg_element("path");
      path1 = svg_element("path");
      path2 = svg_element("path");
      path3 = svg_element("path");
      path4 = svg_element("path");
      path5 = svg_element("path");
      attr(path0, "d", "M896.594 397.344C886.965 397.154 877.434 401.598 871.469 410.062L826.938 473.25C826.919 473.275 826.893 473.287 826.875 473.312L797.188 515.438L765.625 560.219C765.611 560.239 765.608 560.261 765.594 560.281L633.906 747.156C624.362 760.7 627.613 779.393 641.156 788.938C654.7 798.482 673.424 795.262 682.969 781.719L814.688 594.781L875.938 507.875L875.969 507.812L920.5 444.625C930.044 431.082 926.825 412.357 913.281 402.812C908.203 399.233 902.371 397.458 896.594 397.344Z");
      attr(path0, "fill-rule", "nonzero");
      attr(path0, "stroke", "none");
      attr(path0, "class", "svelte-131cm5t");
      attr(path1, "d", "M375.375 30C365.746 29.8099 356.184 34.2542 350.219 42.7188L112.656 379.812C103.112 393.356 106.363 412.049 119.906 421.594C133.45 431.138 152.174 427.918 161.719 414.375L399.25 77.2812C408.794 63.738 405.575 45.0132 392.031 35.4688C386.953 31.8896 381.152 30.1141 375.375 30Z");
      attr(path1, "fill-rule", "nonzero");
      attr(path1, "stroke", "none");
      attr(path1, "class", "svelte-131cm5t");
      attr(path2, "d", "M156.688 921.625C142.88 921.606 131.676 932.787 131.656 946.594C131.637 960.401 142.818 971.606 156.625 971.625L908.938 972.688C922.745 972.707 933.949 961.526 933.969 947.719C933.988 933.912 922.807 922.707 909 922.688L156.688 921.625Z");
      attr(path2, "fill-rule", "nonzero");
      attr(path2, "stroke", "none");
      attr(path2, "class", "svelte-131cm5t");
      attr(path3, "d", "M699.531 123.5C689.903 123.31 680.34 127.754 674.375 136.219L417.875 500.188C408.331 513.731 411.582 532.456 425.125 542C438.668 551.544 457.393 548.293 466.938 534.75L723.438 170.781C732.982 157.238 729.731 138.513 716.188 128.969C711.109 125.39 705.308 123.614 699.531 123.5Z");
      attr(path3, "fill-rule", "nonzero");
      attr(path3, "stroke", "none");
      attr(path3, "class", "svelte-131cm5t");
      attr(path4, "d", "M238.344 363.125C235.385 363.254 232.411 363.534 229.438 363.969C229.307 363.988 123.281 380.906 123.281 380.906C108.195 383.314 97.3175 396.677 98.0312 411.938L122.438 933.688C123.356 953.319 142.584 966.764 161.344 960.906L658.125 805.781C672.641 801.249 681.486 786.572 678.688 771.625C678.688 771.625 659.056 666.875 659.031 666.75C649.584 619.609 602.794 586.614 555.219 593.562L505.906 600.75L495.188 547.25C490.747 525.095 478.037 505.871 459.906 493.094C459.906 493.094 419.392 474.824 397.031 478.094L343.312 485.938L333.219 437.125C324.362 392.93 282.718 361.194 238.344 363.125ZM244.125 423.125C258.167 424.085 271.626 435.035 274.406 448.906L290.281 525.781C293.495 541.339 308.28 551.704 324 549.406L405.719 537.438C412.729 536.412 419.657 538.149 425.344 542.156C425.344 542.156 434.983 552.118 436.375 559.062L452.594 640.031C454.104 647.564 458.439 654.23 464.719 658.656L465.25 659.031C471.529 663.456 479.274 665.297 486.875 664.188L563.875 652.938C579.881 650.6 597.042 662.679 600.219 678.531L614.812 756.469L180.562 892.062L159.219 435.938L238.094 423.344C240.094 423.052 242.119 422.988 244.125 423.125Z");
      attr(path4, "fill-rule", "nonzero");
      attr(path4, "stroke", "none");
      attr(path4, "class", "svelte-131cm5t");
      attr(path5, "d", "M136.068 749.979C132.698 730.522 152.063 714.963 170.337 722.445L202.804 735.739C244.759 752.917 281.717 780.376 310.274 815.587L327.513 836.843C347.189 849.842 340.838 880.21 317.601 884.235L188.683 906.564C175.013 908.932 162.013 899.77 159.645 886.1L136.068 749.979Z");
      attr(path5, "fill-rule", "nonzero");
      attr(path5, "stroke", "none");
      attr(path5, "class", "svelte-131cm5t");
      attr(svg, "height", "100%");
      attr(svg, "stroke-miterlimit", "10");
      set_style(svg, "fill-rule", "nonzero");
      set_style(svg, "clip-rule", "evenodd");
      set_style(svg, "stroke-linecap", "round");
      set_style(svg, "stroke-linejoin", "round");
      attr(svg, "viewBox", "0 0 1024 1024");
      attr(svg, "width", "25px");
      attr(svg, "xml:space", "preserve");
      attr(svg, "xmlns", "http://www.w3.org/2000/svg");
    },
    m(target, anchor) {
      insert(target, svg, anchor);
      append(svg, path0);
      append(svg, path1);
      append(svg, path2);
      append(svg, path3);
      append(svg, path4);
      append(svg, path5);
    },
    p: noop,
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(svg);
      }
    }
  };
}
class EditIcon extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, null, create_fragment$o, safe_not_equal, {});
  }
}
const Link_svelte_svelte_type_style_lang = "";
function create_fragment$n(ctx) {
  let a;
  let span;
  let current;
  const default_slot_template = (
    /*#slots*/
    ctx[3].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[2],
    null
  );
  return {
    c() {
      a = element("a");
      if (default_slot)
        default_slot.c();
      span = element("span");
      attr(span, "class", "svelte-12mlbl");
      attr(
        a,
        "href",
        /*href*/
        ctx[0]
      );
      attr(
        a,
        "title",
        /*title*/
        ctx[1]
      );
      attr(a, "class", "svelte-12mlbl");
    },
    m(target, anchor) {
      insert(target, a, anchor);
      if (default_slot) {
        default_slot.m(a, null);
      }
      append(a, span);
      current = true;
    },
    p(ctx2, [dirty]) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        4)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[2],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[2]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[2],
              dirty,
              null
            ),
            null
          );
        }
      }
      if (!current || dirty & /*href*/
      1) {
        attr(
          a,
          "href",
          /*href*/
          ctx2[0]
        );
      }
      if (!current || dirty & /*title*/
      2) {
        attr(
          a,
          "title",
          /*title*/
          ctx2[1]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(a);
      }
      if (default_slot)
        default_slot.d(detaching);
    }
  };
}
function instance$j($$self, $$props, $$invalidate) {
  let { $$slots: slots = {}, $$scope } = $$props;
  let { href } = $$props;
  let { title = "" } = $$props;
  $$self.$$set = ($$props2) => {
    if ("href" in $$props2)
      $$invalidate(0, href = $$props2.href);
    if ("title" in $$props2)
      $$invalidate(1, title = $$props2.title);
    if ("$$scope" in $$props2)
      $$invalidate(2, $$scope = $$props2.$$scope);
  };
  return [href, title, $$scope, slots];
}
class Link extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$j, create_fragment$n, safe_not_equal, { href: 0, title: 1 });
  }
}
const EditButton_svelte_svelte_type_style_lang = "";
function create_fragment$m(ctx) {
  let button;
  let current;
  let mounted;
  let dispose;
  const default_slot_template = (
    /*#slots*/
    ctx[4].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[3],
    null
  );
  return {
    c() {
      button = element("button");
      if (default_slot)
        default_slot.c();
      attr(button, "class", "svelte-mfv22u");
      toggle_class(
        button,
        "hide",
        /*$settings*/
        ctx[1].editable
      );
    },
    m(target, anchor) {
      insert(target, button, anchor);
      if (default_slot) {
        default_slot.m(button, null);
      }
      current = true;
      if (!mounted) {
        dispose = listen(button, "click", function() {
          if (is_function(
            /*onClick*/
            ctx[0]
          ))
            ctx[0].apply(this, arguments);
        });
        mounted = true;
      }
    },
    p(new_ctx, [dirty]) {
      ctx = new_ctx;
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        8)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx,
            /*$$scope*/
            ctx[3],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx[3]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx[3],
              dirty,
              null
            ),
            null
          );
        }
      }
      if (!current || dirty & /*$settings*/
      2) {
        toggle_class(
          button,
          "hide",
          /*$settings*/
          ctx[1].editable
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(button);
      }
      if (default_slot)
        default_slot.d(detaching);
      mounted = false;
      dispose();
    }
  };
}
function instance$i($$self, $$props, $$invalidate) {
  let $settings;
  let { $$slots: slots = {}, $$scope } = $$props;
  const settings = getSettings();
  component_subscribe($$self, settings, (value) => $$invalidate(1, $settings = value));
  let { onClick = () => {
  } } = $$props;
  $$self.$$set = ($$props2) => {
    if ("onClick" in $$props2)
      $$invalidate(0, onClick = $$props2.onClick);
    if ("$$scope" in $$props2)
      $$invalidate(3, $$scope = $$props2.$$scope);
  };
  return [onClick, $settings, settings, $$scope, slots];
}
class EditButton extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$i, create_fragment$m, safe_not_equal, { onClick: 0 });
  }
}
const Card_svelte_svelte_type_style_lang = "";
function get_each_context$7(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[6] = list[i].label;
  child_ctx[7] = list[i].url;
  return child_ctx;
}
function create_default_slot_1$6(ctx) {
  let editicon;
  let current;
  editicon = new EditIcon({});
  return {
    c() {
      create_component(editicon.$$.fragment);
    },
    m(target, anchor) {
      mount_component(editicon, target, anchor);
      current = true;
    },
    i(local) {
      if (current)
        return;
      transition_in(editicon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(editicon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(editicon, detaching);
    }
  };
}
function create_default_slot$8(ctx) {
  let t_value = (
    /*label*/
    ctx[6] + ""
  );
  let t;
  return {
    c() {
      t = text(t_value);
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*card*/
      1 && t_value !== (t_value = /*label*/
      ctx2[6] + ""))
        set_data(t, t_value);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_each_block$7(ctx) {
  let li;
  let link;
  let t;
  let current;
  link = new Link({
    props: {
      href: (
        /*url*/
        ctx[7]
      ),
      $$slots: { default: [create_default_slot$8] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      li = element("li");
      create_component(link.$$.fragment);
      t = space();
    },
    m(target, anchor) {
      insert(target, li, anchor);
      mount_component(link, li, null);
      append(li, t);
      current = true;
    },
    p(ctx2, dirty) {
      const link_changes = {};
      if (dirty & /*card*/
      1)
        link_changes.href = /*url*/
        ctx2[7];
      if (dirty & /*$$scope, card*/
      1025) {
        link_changes.$$scope = { dirty, ctx: ctx2 };
      }
      link.$set(link_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(link.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(link.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(li);
      }
      destroy_component(link);
    }
  };
}
function create_fragment$l(ctx) {
  let component;
  let div;
  let h2;
  let t0_value = (
    /*card*/
    ctx[0].title + ""
  );
  let t0;
  let t1;
  let editbutton;
  let t2;
  let ul;
  let current;
  editbutton = new EditButton({
    props: {
      onClick: (
        /*func*/
        ctx[5]
      ),
      $$slots: { default: [create_default_slot_1$6] },
      $$scope: { ctx }
    }
  });
  let each_value = ensure_array_like(
    /*card*/
    ctx[0].links
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$7(get_each_context$7(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  return {
    c() {
      component = element("component");
      div = element("div");
      h2 = element("h2");
      t0 = text(t0_value);
      t1 = space();
      create_component(editbutton.$$.fragment);
      t2 = space();
      ul = element("ul");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      attr(div, "class", "header svelte-dw07cx");
      attr(ul, "class", "svelte-dw07cx");
      attr(component, "class", "svelte-dw07cx");
    },
    m(target, anchor) {
      insert(target, component, anchor);
      append(component, div);
      append(div, h2);
      append(h2, t0);
      append(div, t1);
      mount_component(editbutton, div, null);
      append(component, t2);
      append(component, ul);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(ul, null);
        }
      }
      current = true;
    },
    p(ctx2, [dirty]) {
      if ((!current || dirty & /*card*/
      1) && t0_value !== (t0_value = /*card*/
      ctx2[0].title + ""))
        set_data(t0, t0_value);
      const editbutton_changes = {};
      if (dirty & /*$layerConfig, onChangeSelectedCard, cardIndex*/
      14)
        editbutton_changes.onClick = /*func*/
        ctx2[5];
      if (dirty & /*$$scope*/
      1024) {
        editbutton_changes.$$scope = { dirty, ctx: ctx2 };
      }
      editbutton.$set(editbutton_changes);
      if (dirty & /*card*/
      1) {
        each_value = ensure_array_like(
          /*card*/
          ctx2[0].links
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$7(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block$7(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(ul, null);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(editbutton.$$.fragment, local);
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      transition_out(editbutton.$$.fragment, local);
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(component);
      }
      destroy_component(editbutton);
      destroy_each(each_blocks, detaching);
    }
  };
}
function instance$h($$self, $$props, $$invalidate) {
  let $layerConfig;
  let { card } = $$props;
  let { cardIndex } = $$props;
  let layerConfig = getLayerConfig();
  component_subscribe($$self, layerConfig, (value) => $$invalidate(3, $layerConfig = value));
  let { onChangeSelectedCard } = $$props;
  const func2 = () => {
    set_store_value(
      layerConfig,
      $layerConfig = {
        activate: true,
        type: "drawer",
        subtype: "card"
      },
      $layerConfig
    );
    onChangeSelectedCard(cardIndex);
  };
  $$self.$$set = ($$props2) => {
    if ("card" in $$props2)
      $$invalidate(0, card = $$props2.card);
    if ("cardIndex" in $$props2)
      $$invalidate(1, cardIndex = $$props2.cardIndex);
    if ("onChangeSelectedCard" in $$props2)
      $$invalidate(2, onChangeSelectedCard = $$props2.onChangeSelectedCard);
  };
  return [card, cardIndex, onChangeSelectedCard, $layerConfig, layerConfig, func2];
}
class Card extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$h, create_fragment$l, safe_not_equal, {
      card: 0,
      cardIndex: 1,
      onChangeSelectedCard: 2
    });
  }
}
const CardsList_svelte_svelte_type_style_lang = "";
function get_each_context$6(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[2] = list[i];
  child_ctx[4] = i;
  return child_ctx;
}
function create_if_block$2(ctx) {
  let each_1_anchor;
  let current;
  let each_value = ensure_array_like(
    /*cards*/
    ctx[0]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$6(get_each_context$6(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  return {
    c() {
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      each_1_anchor = empty();
    },
    m(target, anchor) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(target, anchor);
        }
      }
      insert(target, each_1_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty & /*cards, onChangeSelectedCard*/
      3) {
        each_value = ensure_array_like(
          /*cards*/
          ctx2[0]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$6(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block$6(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(each_1_anchor.parentNode, each_1_anchor);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(each_1_anchor);
      }
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_each_block$6(ctx) {
  let card_1;
  let current;
  card_1 = new Card({
    props: {
      card: (
        /*card*/
        ctx[2]
      ),
      cardIndex: (
        /*index*/
        ctx[4]
      ),
      onChangeSelectedCard: (
        /*onChangeSelectedCard*/
        ctx[1]
      )
    }
  });
  return {
    c() {
      create_component(card_1.$$.fragment);
    },
    m(target, anchor) {
      mount_component(card_1, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const card_1_changes = {};
      if (dirty & /*cards*/
      1)
        card_1_changes.card = /*card*/
        ctx2[2];
      if (dirty & /*onChangeSelectedCard*/
      2)
        card_1_changes.onChangeSelectedCard = /*onChangeSelectedCard*/
        ctx2[1];
      card_1.$set(card_1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(card_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(card_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(card_1, detaching);
    }
  };
}
function create_fragment$k(ctx) {
  var _a;
  let component;
  let current;
  let if_block = (
    /*cards*/
    ((_a = ctx[0]) == null ? void 0 : _a.length) && create_if_block$2(ctx)
  );
  return {
    c() {
      component = element("component");
      if (if_block)
        if_block.c();
      attr(component, "class", "svelte-que3gf");
    },
    m(target, anchor) {
      insert(target, component, anchor);
      if (if_block)
        if_block.m(component, null);
      current = true;
    },
    p(ctx2, [dirty]) {
      var _a2;
      if (
        /*cards*/
        (_a2 = ctx2[0]) == null ? void 0 : _a2.length
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*cards*/
          1) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block$2(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(component, null);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(component);
      }
      if (if_block)
        if_block.d();
    }
  };
}
function instance$g($$self, $$props, $$invalidate) {
  let { cards } = $$props;
  let { onChangeSelectedCard } = $$props;
  $$self.$$set = ($$props2) => {
    if ("cards" in $$props2)
      $$invalidate(0, cards = $$props2.cards);
    if ("onChangeSelectedCard" in $$props2)
      $$invalidate(1, onChangeSelectedCard = $$props2.onChangeSelectedCard);
  };
  return [cards, onChangeSelectedCard];
}
class CardsList extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$g, create_fragment$k, safe_not_equal, { cards: 0, onChangeSelectedCard: 1 });
  }
}
function fade(node, { delay = 0, duration = 400, easing = identity } = {}) {
  const o = +getComputedStyle(node).opacity;
  return {
    delay,
    duration,
    easing,
    css: (t) => `opacity: ${t * o}`
  };
}
const Drawer_svelte_svelte_type_style_lang = "";
function create_if_block$1(ctx) {
  let component;
  let div0;
  let h1;
  let t0;
  let t1;
  let button;
  let t3;
  let div1;
  let component_inert_value;
  let component_transition;
  let t4;
  let div2;
  let div2_transition;
  let current;
  let mounted;
  let dispose;
  const default_slot_template = (
    /*#slots*/
    ctx[6].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[5],
    null
  );
  return {
    c() {
      component = element("component");
      div0 = element("div");
      h1 = element("h1");
      t0 = text(
        /*title*/
        ctx[0]
      );
      t1 = space();
      button = element("button");
      button.textContent = "×";
      t3 = space();
      div1 = element("div");
      if (default_slot)
        default_slot.c();
      t4 = space();
      div2 = element("div");
      attr(h1, "class", "svelte-c56gi8");
      attr(button, "class", "svelte-c56gi8");
      attr(div0, "class", "header svelte-c56gi8");
      component.inert = component_inert_value = !/*$layerConfig*/
      ctx[1].activate;
      attr(component, "role", "dialog");
      attr(component, "class", "drawer svelte-c56gi8");
      attr(div2, "role", "dialog");
      attr(div2, "class", "overlay svelte-c56gi8");
    },
    m(target, anchor) {
      insert(target, component, anchor);
      append(component, div0);
      append(div0, h1);
      append(h1, t0);
      append(div0, t1);
      append(div0, button);
      append(component, t3);
      append(component, div1);
      if (default_slot) {
        default_slot.m(div1, null);
      }
      insert(target, t4, anchor);
      insert(target, div2, anchor);
      current = true;
      if (!mounted) {
        dispose = [
          listen(
            button,
            "click",
            /*onClickHandler*/
            ctx[4]
          ),
          listen(
            div2,
            "click",
            /*onClickHandler*/
            ctx[4]
          )
        ];
        mounted = true;
      }
    },
    p(ctx2, dirty) {
      if (!current || dirty & /*title*/
      1)
        set_data(
          t0,
          /*title*/
          ctx2[0]
        );
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        32)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[5],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[5]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[5],
              dirty,
              null
            ),
            null
          );
        }
      }
      if (!current || dirty & /*$layerConfig*/
      2 && component_inert_value !== (component_inert_value = !/*$layerConfig*/
      ctx2[1].activate)) {
        component.inert = component_inert_value;
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      if (local) {
        add_render_callback(() => {
          if (!current)
            return;
          if (!component_transition)
            component_transition = create_bidirectional_transition(component, customSlide, { duration: 250 }, true);
          component_transition.run(1);
        });
      }
      if (local) {
        add_render_callback(() => {
          if (!current)
            return;
          if (!div2_transition)
            div2_transition = create_bidirectional_transition(div2, fade, { duration: 250 }, true);
          div2_transition.run(1);
        });
      }
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      if (local) {
        if (!component_transition)
          component_transition = create_bidirectional_transition(component, customSlide, { duration: 250 }, false);
        component_transition.run(0);
      }
      if (local) {
        if (!div2_transition)
          div2_transition = create_bidirectional_transition(div2, fade, { duration: 250 }, false);
        div2_transition.run(0);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(component);
        detach(t4);
        detach(div2);
      }
      if (default_slot)
        default_slot.d(detaching);
      if (detaching && component_transition)
        component_transition.end();
      if (detaching && div2_transition)
        div2_transition.end();
      mounted = false;
      run_all(dispose);
    }
  };
}
function create_fragment$j(ctx) {
  let if_block_anchor;
  let current;
  let mounted;
  let dispose;
  let if_block = (
    /*$layerConfig*/
    ctx[1].activate && create_if_block$1(ctx)
  );
  return {
    c() {
      if (if_block)
        if_block.c();
      if_block_anchor = empty();
    },
    m(target, anchor) {
      if (if_block)
        if_block.m(target, anchor);
      insert(target, if_block_anchor, anchor);
      current = true;
      if (!mounted) {
        dispose = listen(
          window,
          "keydown",
          /*onEsc*/
          ctx[3]
        );
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (
        /*$layerConfig*/
        ctx2[1].activate
      ) {
        if (if_block) {
          if_block.p(ctx2, dirty);
          if (dirty & /*$layerConfig*/
          2) {
            transition_in(if_block, 1);
          }
        } else {
          if_block = create_if_block$1(ctx2);
          if_block.c();
          transition_in(if_block, 1);
          if_block.m(if_block_anchor.parentNode, if_block_anchor);
        }
      } else if (if_block) {
        group_outros();
        transition_out(if_block, 1, 1, () => {
          if_block = null;
        });
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(if_block);
      current = true;
    },
    o(local) {
      transition_out(if_block);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(if_block_anchor);
      }
      if (if_block)
        if_block.d(detaching);
      mounted = false;
      dispose();
    }
  };
}
function customSlide(node, { duration = 250 }) {
  return {
    duration,
    css: (t) => {
      return `
           transform: translateX(${360 + t * -360}px);
        `;
    }
  };
}
function instance$f($$self, $$props, $$invalidate) {
  let $layerConfig;
  let { $$slots: slots = {}, $$scope } = $$props;
  let { title } = $$props;
  const layerConfig = getLayerConfig();
  component_subscribe($$self, layerConfig, (value) => $$invalidate(1, $layerConfig = value));
  const onEsc = (event) => {
    if (event.code === "Escape") {
      set_store_value(layerConfig, $layerConfig = { ...$layerConfig, activate: false }, $layerConfig);
    }
  };
  const onClickHandler = () => {
    set_store_value(layerConfig, $layerConfig = { ...$layerConfig, activate: false }, $layerConfig);
  };
  $$self.$$set = ($$props2) => {
    if ("title" in $$props2)
      $$invalidate(0, title = $$props2.title);
    if ("$$scope" in $$props2)
      $$invalidate(5, $$scope = $$props2.$$scope);
  };
  return [title, $layerConfig, layerConfig, onEsc, onClickHandler, $$scope, slots];
}
class Drawer extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$f, create_fragment$j, safe_not_equal, { title: 0 });
  }
}
const DragIcon_svelte_svelte_type_style_lang = "";
function create_fragment$i(ctx) {
  let svg;
  let circle0;
  let circle1;
  let circle2;
  let circle3;
  let circle4;
  let circle5;
  let circle6;
  let circle7;
  return {
    c() {
      svg = svg_element("svg");
      circle0 = svg_element("circle");
      circle1 = svg_element("circle");
      circle2 = svg_element("circle");
      circle3 = svg_element("circle");
      circle4 = svg_element("circle");
      circle5 = svg_element("circle");
      circle6 = svg_element("circle");
      circle7 = svg_element("circle");
      attr(circle0, "vector-effect", "non-scaling-stroke");
      attr(circle0, "cx", "464.50000000000006");
      attr(circle0, "cy", "202.5");
      attr(circle0, "r", "11");
      attr(circle0, "class", "fill-circle svelte-tk79ke");
      attr(circle1, "vector-effect", "non-scaling-stroke");
      attr(circle1, "cx", "464.50000000000006");
      attr(circle1, "cy", "246.5");
      attr(circle1, "r", "11");
      attr(circle1, "class", "fill-circle svelte-tk79ke");
      attr(circle2, "vector-effect", "non-scaling-stroke");
      attr(circle2, "cx", "464.50000000000006");
      attr(circle2, "cy", "290.5");
      attr(circle2, "r", "11");
      attr(circle2, "class", "fill-circle svelte-tk79ke");
      attr(circle3, "vector-effect", "non-scaling-stroke");
      attr(circle3, "cx", "464.50000000000006");
      attr(circle3, "cy", "334.5");
      attr(circle3, "r", "11");
      attr(circle3, "class", "fill-circle svelte-tk79ke");
      attr(circle4, "vector-effect", "non-scaling-stroke");
      attr(circle4, "cx", "508.5");
      attr(circle4, "cy", "202.5");
      attr(circle4, "r", "11");
      attr(circle4, "class", "fill-circle svelte-tk79ke");
      attr(circle5, "vector-effect", "non-scaling-stroke");
      attr(circle5, "cx", "508.5");
      attr(circle5, "cy", "246.5");
      attr(circle5, "r", "11");
      attr(circle5, "class", "fill-circle svelte-tk79ke");
      attr(circle6, "vector-effect", "non-scaling-stroke");
      attr(circle6, "cx", "508.5");
      attr(circle6, "cy", "290.5");
      attr(circle6, "r", "11");
      attr(circle6, "class", "fill-circle svelte-tk79ke");
      attr(circle7, "vector-effect", "non-scaling-stroke");
      attr(circle7, "cx", "508.5");
      attr(circle7, "cy", "334.5");
      attr(circle7, "r", "11");
      attr(circle7, "class", "fill-circle svelte-tk79ke");
      attr(svg, "viewBox", "453 191 67 155");
      attr(svg, "width", "11px");
      attr(svg, "height", "26px");
    },
    m(target, anchor) {
      insert(target, svg, anchor);
      append(svg, circle0);
      append(svg, circle1);
      append(svg, circle2);
      append(svg, circle3);
      append(svg, circle4);
      append(svg, circle5);
      append(svg, circle6);
      append(svg, circle7);
    },
    p: noop,
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(svg);
      }
    }
  };
}
class DragIcon extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, null, create_fragment$i, safe_not_equal, {});
  }
}
const RemoveIcon_svelte_svelte_type_style_lang = "";
function create_fragment$h(ctx) {
  let svg;
  let g;
  let path0;
  let path1;
  let path2;
  let path3;
  let path4;
  return {
    c() {
      svg = svg_element("svg");
      g = svg_element("g");
      path0 = svg_element("path");
      path1 = svg_element("path");
      path2 = svg_element("path");
      path3 = svg_element("path");
      path4 = svg_element("path");
      attr(path0, "d", "M325.381 382.407C314.046 381.359 301.903 390.793 303.29 409.112C303.354 409.947 335.616 835.863 335.68 836.698C338.147 869.266 378.456 864.789 375.99 832.221C375.927 831.386 343.664 405.471 343.6 404.636C342.521 390.387 334.198 383.223 325.381 382.407Z");
      attr(path0, "fill", "#000000");
      attr(path0, "fill-rule", "nonzero");
      attr(path0, "opacity", "1");
      attr(path0, "stroke", "none");
      attr(path0, "class", "svelte-131cm5t");
      attr(path1, "d", "M514.409 380.58C504.289 380.443 494.088 388.481 493.939 404.831L489.991 834.197C489.691 866.898 530.177 867.45 530.478 834.748C530.485 833.909 534.417 406.223 534.425 405.384C534.575 389.032 524.53 380.716 514.409 380.58Z");
      attr(path1, "fill", "#000000");
      attr(path1, "fill-rule", "nonzero");
      attr(path1, "opacity", "1");
      attr(path1, "stroke", "none");
      attr(path1, "class", "svelte-131cm5t");
      attr(path2, "d", "M697.947 380.657C689.13 381.473 680.807 388.637 679.728 402.886L647.339 830.472C644.871 863.039 685.181 867.516 687.648 834.949C687.711 834.114 719.974 408.197 720.037 407.362C721.425 389.044 709.282 379.609 697.947 380.657Z");
      attr(path2, "fill", "#000000");
      attr(path2, "fill-rule", "nonzero");
      attr(path2, "opacity", "1");
      attr(path2, "stroke", "none");
      attr(path2, "class", "svelte-131cm5t");
      attr(path3, "d", "M345.701 40.231C332.963 41.2006 323.513 53.0472 324.591 66.6905C324.643 67.3374 328.821 120.187 331.135 149.45L165.369 162.069C155.179 162.845 147.618 172.322 148.481 183.237L150.043 239.378L357.322 223.598L666.57 200.057L873.878 184.275L872.316 128.134C871.454 117.219 862.493 108.999 852.303 109.775L686.508 122.396L679.965 39.6373C678.886 25.9936 667.686 15.7192 654.949 16.6889L345.701 40.231ZM377.485 92.623L630.981 72.5902L635.57 125.906L381.111 145.94C379.487 125.409 379.108 113.154 377.485 92.623Z");
      attr(path3, "fill", "#000000");
      attr(path3, "fill-rule", "nonzero");
      attr(path3, "opacity", "1");
      attr(path3, "stroke", "none");
      attr(path3, "class", "svelte-131cm5t");
      attr(path4, "d", "M191.931 233.585C172.265 233.585 156.706 250.185 157.955 269.812C158.042 271.187 202.672 972.717 202.759 974.092C203.901 992.031 218.791 1006 236.766 1006L782.055 1006C800.03 1006 814.921 992.031 816.062 974.092L860.867 269.812C862.115 250.185 846.526 233.585 826.86 233.585L191.931 233.585ZM228.249 301.719L790.572 301.719L750.087 937.865L268.704 937.865C265.147 881.961 232.255 364.68 228.249 301.719Z");
      attr(path4, "fill", "#000000");
      attr(path4, "fill-rule", "nonzero");
      attr(path4, "opacity", "1");
      attr(path4, "stroke", "none");
      attr(path4, "class", "svelte-131cm5t");
      attr(g, "id", "Layer-1");
      attr(svg, "height", "100%");
      attr(svg, "stroke-miterlimit", "10");
      set_style(svg, "fill-rule", "nonzero");
      set_style(svg, "clip-rule", "evenodd");
      set_style(svg, "stroke-linecap", "round");
      set_style(svg, "stroke-linejoin", "round");
      attr(svg, "viewBox", "0 0 1024 1024");
      attr(svg, "width", "20");
      attr(svg, "xml:space", "preserve");
      attr(svg, "xmlns", "http://www.w3.org/2000/svg");
    },
    m(target, anchor) {
      insert(target, svg, anchor);
      append(svg, g);
      append(g, path0);
      append(g, path1);
      append(g, path2);
      append(g, path3);
      append(g, path4);
    },
    p: noop,
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(svg);
      }
    }
  };
}
class RemoveIcon extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, null, create_fragment$h, safe_not_equal, {});
  }
}
const DraggableItem_svelte_svelte_type_style_lang = "";
function create_default_slot$7(ctx) {
  let removeicon;
  let current;
  removeicon = new RemoveIcon({});
  return {
    c() {
      create_component(removeicon.$$.fragment);
    },
    m(target, anchor) {
      mount_component(removeicon, target, anchor);
      current = true;
    },
    i(local) {
      if (current)
        return;
      transition_in(removeicon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(removeicon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(removeicon, detaching);
    }
  };
}
function create_fragment$g(ctx) {
  let li;
  let button0;
  let div;
  let t0;
  let t1;
  let button1;
  let dragicon;
  let current;
  let mounted;
  let dispose;
  button0 = new Button({
    props: {
      onClick: (
        /*func*/
        ctx[14]
      ),
      $$slots: { default: [create_default_slot$7] },
      $$scope: { ctx }
    }
  });
  const default_slot_template = (
    /*#slots*/
    ctx[13].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[17],
    null
  );
  dragicon = new DragIcon({});
  return {
    c() {
      var _a;
      li = element("li");
      div = element("div");
      create_component(button0.$$.fragment);
      t0 = space();
      if (default_slot)
        default_slot.c();
      t1 = space();
      button1 = element("button");
      create_component(dragicon.$$.fragment);
      set_style(div, "display", "contents");
      set_style(div, "--color-accent", "transparent");
      attr(button1, "class", "drag-button svelte-1eb9k0e");
      attr(li, "class", "list-item svelte-1eb9k0e");
      attr(
        li,
        "data-index",
        /*index*/
        ctx[1]
      );
      attr(
        li,
        "draggable",
        /*isDragEnabled*/
        ctx[0]
      );
      toggle_class(
        li,
        "dragged-list-item",
        /*$draggableList*/
        ((_a = ctx[2]) == null ? void 0 : _a.draggedOver) === /*index*/
        ctx[1]
      );
    },
    m(target, anchor) {
      insert(target, li, anchor);
      append(li, div);
      mount_component(button0, div, null);
      append(li, t0);
      if (default_slot) {
        default_slot.m(li, null);
      }
      append(li, t1);
      append(li, button1);
      mount_component(dragicon, button1, null);
      current = true;
      if (!mounted) {
        dispose = [
          listen(
            button1,
            "mouseover",
            /*mouseover_handler*/
            ctx[15]
          ),
          listen(
            button1,
            "mouseout",
            /*mouseout_handler*/
            ctx[16]
          ),
          listen(button1, "focus", focus_handler$1),
          listen(button1, "blur", blur_handler$1),
          listen(
            li,
            "dragover",
            /*enableDropping*/
            ctx[5]
          ),
          listen(
            li,
            "dragstart",
            /*handleDragStart*/
            ctx[4]
          ),
          listen(
            li,
            "drop",
            /*handleDrop*/
            ctx[8]
          ),
          listen(
            li,
            "dragenter",
            /*handleDragEnter*/
            ctx[6]
          ),
          listen(
            li,
            "dragend",
            /*handleDragEnd*/
            ctx[7]
          )
        ];
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      var _a;
      const button0_changes = {};
      if (dirty & /*index*/
      2)
        button0_changes.onClick = /*func*/
        ctx2[14];
      if (dirty & /*$$scope*/
      131072) {
        button0_changes.$$scope = { dirty, ctx: ctx2 };
      }
      button0.$set(button0_changes);
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        131072)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[17],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[17]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[17],
              dirty,
              null
            ),
            null
          );
        }
      }
      if (!current || dirty & /*index*/
      2) {
        attr(
          li,
          "data-index",
          /*index*/
          ctx2[1]
        );
      }
      if (!current || dirty & /*isDragEnabled*/
      1) {
        attr(
          li,
          "draggable",
          /*isDragEnabled*/
          ctx2[0]
        );
      }
      if (!current || dirty & /*$draggableList, index*/
      6) {
        toggle_class(
          li,
          "dragged-list-item",
          /*$draggableList*/
          ((_a = ctx2[2]) == null ? void 0 : _a.draggedOver) === /*index*/
          ctx2[1]
        );
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(button0.$$.fragment, local);
      transition_in(default_slot, local);
      transition_in(dragicon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(button0.$$.fragment, local);
      transition_out(default_slot, local);
      transition_out(dragicon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(li);
      }
      destroy_component(button0);
      if (default_slot)
        default_slot.d(detaching);
      destroy_component(dragicon);
      mounted = false;
      run_all(dispose);
    }
  };
}
const focus_handler$1 = () => {
};
const blur_handler$1 = () => {
};
function instance$e($$self, $$props, $$invalidate) {
  let $draggableList;
  let { $$slots: slots = {}, $$scope } = $$props;
  let { key } = $$props;
  let { dataArray } = $$props;
  let { index: index2 } = $$props;
  let { onArrayUpdate } = $$props;
  let { isDragEnabled } = $$props;
  const draggableList = getContextByDraggableList(key);
  component_subscribe($$self, draggableList, (value) => $$invalidate(2, $draggableList = value));
  function handleDragStart(event) {
    if (event) {
      const currentTarget = event.currentTarget;
      if (typeof currentTarget.dataset.index !== "undefined") {
        set_store_value(
          draggableList,
          $draggableList = {
            ...$draggableList,
            grabbed: parseInt(currentTarget.dataset.index)
          },
          $draggableList
        );
      }
    }
  }
  const enableDropping = (event) => {
    if ($draggableList.activeListArea) {
      event.preventDefault();
    }
  };
  function handleDragEnter(event) {
    if ($draggableList.activeListArea) {
      const currentTarget = event.currentTarget;
      const index22 = currentTarget.dataset.index;
      if (typeof index22 !== "undefined" && key === $draggableList.key) {
        set_store_value(
          draggableList,
          $draggableList = {
            ...$draggableList,
            draggedOver: parseInt(index22)
          },
          $draggableList
        );
      }
    }
  }
  function handleDragEnd() {
    set_store_value(draggableList, $draggableList = { ...$draggableList, draggedOver: -1 }, $draggableList);
  }
  function handleDrop(event) {
    const currentTarget = event.currentTarget;
    const index22 = currentTarget.dataset.index;
    if (typeof index22 !== "undefined") {
      const dataToChange = [...dataArray];
      const dataToMove = dataToChange.splice($draggableList.grabbed, 1);
      dataToChange.splice(parseInt(index22), 0, dataToMove[0]);
      onArrayUpdate(dataToChange);
      set_store_value(draggableList, $draggableList = { ...$draggableList, draggedOver: -1 }, $draggableList);
    }
  }
  function handleDelete(linkIndex) {
    const updatedArray = [...dataArray.slice(0, linkIndex), ...dataArray.slice(linkIndex + 1)];
    onArrayUpdate(updatedArray);
  }
  const func2 = () => handleDelete(index2);
  const mouseover_handler = () => $$invalidate(0, isDragEnabled = true);
  const mouseout_handler = () => $$invalidate(0, isDragEnabled = false);
  $$self.$$set = ($$props2) => {
    if ("key" in $$props2)
      $$invalidate(10, key = $$props2.key);
    if ("dataArray" in $$props2)
      $$invalidate(11, dataArray = $$props2.dataArray);
    if ("index" in $$props2)
      $$invalidate(1, index2 = $$props2.index);
    if ("onArrayUpdate" in $$props2)
      $$invalidate(12, onArrayUpdate = $$props2.onArrayUpdate);
    if ("isDragEnabled" in $$props2)
      $$invalidate(0, isDragEnabled = $$props2.isDragEnabled);
    if ("$$scope" in $$props2)
      $$invalidate(17, $$scope = $$props2.$$scope);
  };
  return [
    isDragEnabled,
    index2,
    $draggableList,
    draggableList,
    handleDragStart,
    enableDropping,
    handleDragEnter,
    handleDragEnd,
    handleDrop,
    handleDelete,
    key,
    dataArray,
    onArrayUpdate,
    slots,
    func2,
    mouseover_handler,
    mouseout_handler,
    $$scope
  ];
}
class DraggableItem extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$e, create_fragment$g, safe_not_equal, {
      key: 10,
      dataArray: 11,
      index: 1,
      onArrayUpdate: 12,
      isDragEnabled: 0
    });
  }
}
const DraggableList_svelte_svelte_type_style_lang = "";
function create_fragment$f(ctx) {
  let component;
  let ul;
  let ul_data_test_id_value;
  let current;
  let mounted;
  let dispose;
  const default_slot_template = (
    /*#slots*/
    ctx[5].default
  );
  const default_slot = create_slot(
    default_slot_template,
    ctx,
    /*$$scope*/
    ctx[4],
    null
  );
  return {
    c() {
      component = element("component");
      ul = element("ul");
      if (default_slot)
        default_slot.c();
      attr(ul, "data-test-id", ul_data_test_id_value = `draggable-list__${/*key*/
      ctx[0]}`);
      attr(ul, "class", "svelte-gyj6sw");
      attr(component, "class", "svelte-gyj6sw");
    },
    m(target, anchor) {
      insert(target, component, anchor);
      append(component, ul);
      if (default_slot) {
        default_slot.m(ul, null);
      }
      current = true;
      if (!mounted) {
        dispose = [
          listen(
            ul,
            "mouseover",
            /*handleMouseOver*/
            ctx[2]
          ),
          listen(
            ul,
            "mouseout",
            /*handleMouseOut*/
            ctx[3]
          ),
          listen(ul, "focus", focus_handler),
          listen(ul, "blur", blur_handler)
        ];
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (default_slot) {
        if (default_slot.p && (!current || dirty & /*$$scope*/
        16)) {
          update_slot_base(
            default_slot,
            default_slot_template,
            ctx2,
            /*$$scope*/
            ctx2[4],
            !current ? get_all_dirty_from_scope(
              /*$$scope*/
              ctx2[4]
            ) : get_slot_changes(
              default_slot_template,
              /*$$scope*/
              ctx2[4],
              dirty,
              null
            ),
            null
          );
        }
      }
      if (!current || dirty & /*key*/
      1 && ul_data_test_id_value !== (ul_data_test_id_value = `draggable-list__${/*key*/
      ctx2[0]}`)) {
        attr(ul, "data-test-id", ul_data_test_id_value);
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(default_slot, local);
      current = true;
    },
    o(local) {
      transition_out(default_slot, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(component);
      }
      if (default_slot)
        default_slot.d(detaching);
      mounted = false;
      run_all(dispose);
    }
  };
}
const focus_handler = () => {
};
const blur_handler = () => {
};
function instance$d($$self, $$props, $$invalidate) {
  let $draggableList;
  let { $$slots: slots = {}, $$scope } = $$props;
  let { key } = $$props;
  setContextByDraggableList(key);
  const draggableList = getContextByDraggableList(key);
  component_subscribe($$self, draggableList, (value) => $$invalidate(6, $draggableList = value));
  const handleMouseOver = () => {
    set_store_value(draggableList, $draggableList = { ...$draggableList, activeListArea: true }, $draggableList);
  };
  const handleMouseOut = () => {
    set_store_value(draggableList, $draggableList = { ...$draggableList, activeListArea: false }, $draggableList);
  };
  $$self.$$set = ($$props2) => {
    if ("key" in $$props2)
      $$invalidate(0, key = $$props2.key);
    if ("$$scope" in $$props2)
      $$invalidate(4, $$scope = $$props2.$$scope);
  };
  return [key, draggableList, handleMouseOver, handleMouseOut, $$scope, slots];
}
class DraggableList extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$d, create_fragment$f, safe_not_equal, { key: 0 });
  }
}
const TextField_svelte_svelte_type_style_lang = "";
function create_fragment$e(ctx) {
  let label_1;
  let t0;
  let t1;
  let input;
  let mounted;
  let dispose;
  return {
    c() {
      label_1 = element("label");
      t0 = text(
        /*label*/
        ctx[0]
      );
      t1 = space();
      input = element("input");
      attr(
        input,
        "name",
        /*name*/
        ctx[2]
      );
      input.value = /*value*/
      ctx[1];
      attr(
        input,
        "placeholder",
        /*placeholder*/
        ctx[3]
      );
      attr(input, "type", "text");
      attr(input, "class", "svelte-1nqcxqz");
      toggle_class(
        input,
        "isPlaceholderInput",
        /*isPlaceholderInput*/
        ctx[4]
      );
      attr(label_1, "class", "svelte-1nqcxqz");
      toggle_class(
        label_1,
        "isPlaceholderInput",
        /*isPlaceholderInput*/
        ctx[4]
      );
    },
    m(target, anchor) {
      insert(target, label_1, anchor);
      append(label_1, t0);
      append(label_1, t1);
      append(label_1, input);
      if (!mounted) {
        dispose = [
          listen(input, "change", function() {
            if (is_function(
              /*onChange*/
              ctx[5]
            ))
              ctx[5].apply(this, arguments);
          }),
          listen(input, "input", function() {
            if (is_function(
              /*onInput*/
              ctx[6]
            ))
              ctx[6].apply(this, arguments);
          }),
          action_destroyer(
            /*shouldSetFocus*/
            ctx[7].call(null, input)
          )
        ];
        mounted = true;
      }
    },
    p(new_ctx, [dirty]) {
      ctx = new_ctx;
      if (dirty & /*label*/
      1)
        set_data(
          t0,
          /*label*/
          ctx[0]
        );
      if (dirty & /*name*/
      4) {
        attr(
          input,
          "name",
          /*name*/
          ctx[2]
        );
      }
      if (dirty & /*value*/
      2 && input.value !== /*value*/
      ctx[1]) {
        input.value = /*value*/
        ctx[1];
      }
      if (dirty & /*placeholder*/
      8) {
        attr(
          input,
          "placeholder",
          /*placeholder*/
          ctx[3]
        );
      }
      if (dirty & /*isPlaceholderInput*/
      16) {
        toggle_class(
          input,
          "isPlaceholderInput",
          /*isPlaceholderInput*/
          ctx[4]
        );
      }
      if (dirty & /*isPlaceholderInput*/
      16) {
        toggle_class(
          label_1,
          "isPlaceholderInput",
          /*isPlaceholderInput*/
          ctx[4]
        );
      }
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(label_1);
      }
      mounted = false;
      run_all(dispose);
    }
  };
}
function instance$c($$self, $$props, $$invalidate) {
  let { label = "" } = $$props;
  let { value = "" } = $$props;
  let { name = "" } = $$props;
  let { placeholder = "" } = $$props;
  let { isPlaceholderInput } = $$props;
  let { shouldTakeFocus } = $$props;
  let { onChange = () => {
  } } = $$props;
  let { onInput = () => {
  } } = $$props;
  function shouldSetFocus(node) {
    if (shouldTakeFocus) {
      node.focus();
    }
  }
  $$self.$$set = ($$props2) => {
    if ("label" in $$props2)
      $$invalidate(0, label = $$props2.label);
    if ("value" in $$props2)
      $$invalidate(1, value = $$props2.value);
    if ("name" in $$props2)
      $$invalidate(2, name = $$props2.name);
    if ("placeholder" in $$props2)
      $$invalidate(3, placeholder = $$props2.placeholder);
    if ("isPlaceholderInput" in $$props2)
      $$invalidate(4, isPlaceholderInput = $$props2.isPlaceholderInput);
    if ("shouldTakeFocus" in $$props2)
      $$invalidate(8, shouldTakeFocus = $$props2.shouldTakeFocus);
    if ("onChange" in $$props2)
      $$invalidate(5, onChange = $$props2.onChange);
    if ("onInput" in $$props2)
      $$invalidate(6, onInput = $$props2.onInput);
  };
  return [
    label,
    value,
    name,
    placeholder,
    isPlaceholderInput,
    onChange,
    onInput,
    shouldSetFocus,
    shouldTakeFocus
  ];
}
class TextField extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$c, create_fragment$e, safe_not_equal, {
      label: 0,
      value: 1,
      name: 2,
      placeholder: 3,
      isPlaceholderInput: 4,
      shouldTakeFocus: 8,
      onChange: 5,
      onInput: 6
    });
  }
}
function create_fragment$d(ctx) {
  let textfield;
  let current;
  textfield = new TextField({
    props: {
      value: (
        /*element*/
        ctx[0].title
      ),
      onChange: (
        /*func*/
        ctx[4]
      ),
      name: "title",
      shouldTakeFocus: (
        /*shouldTakeFocus*/
        ctx[2]
      )
    }
  });
  return {
    c() {
      create_component(textfield.$$.fragment);
    },
    m(target, anchor) {
      mount_component(textfield, target, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const textfield_changes = {};
      if (dirty & /*element*/
      1)
        textfield_changes.value = /*element*/
        ctx2[0].title;
      if (dirty & /*onUpdateTab, index*/
      10)
        textfield_changes.onChange = /*func*/
        ctx2[4];
      if (dirty & /*shouldTakeFocus*/
      4)
        textfield_changes.shouldTakeFocus = /*shouldTakeFocus*/
        ctx2[2];
      textfield.$set(textfield_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(textfield.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(textfield.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(textfield, detaching);
    }
  };
}
function instance$b($$self, $$props, $$invalidate) {
  let { element: element2 } = $$props;
  let { index: index2 } = $$props;
  let { shouldTakeFocus } = $$props;
  let { onUpdateTab } = $$props;
  const func2 = (event) => onUpdateTab(event, index2);
  $$self.$$set = ($$props2) => {
    if ("element" in $$props2)
      $$invalidate(0, element2 = $$props2.element);
    if ("index" in $$props2)
      $$invalidate(1, index2 = $$props2.index);
    if ("shouldTakeFocus" in $$props2)
      $$invalidate(2, shouldTakeFocus = $$props2.shouldTakeFocus);
    if ("onUpdateTab" in $$props2)
      $$invalidate(3, onUpdateTab = $$props2.onUpdateTab);
  };
  return [element2, index2, shouldTakeFocus, onUpdateTab, func2];
}
class TabInput extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$b, create_fragment$d, safe_not_equal, {
      element: 0,
      index: 1,
      shouldTakeFocus: 2,
      onUpdateTab: 3
    });
  }
}
const ManageTabsDrawer_svelte_svelte_type_style_lang = "";
function get_each_context$5(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[13] = list[i];
  child_ctx[15] = i;
  return child_ctx;
}
function create_default_slot_3$3(ctx) {
  let tabinput;
  let t;
  let current;
  tabinput = new TabInput({
    props: {
      onUpdateTab: (
        /*handleUpdate*/
        ctx[8]
      ),
      element: (
        /*tab*/
        ctx[13]
      ),
      index: (
        /*index*/
        ctx[15]
      ),
      shouldTakeFocus: (
        /*shouldTakeFocusIndex*/
        ctx[3] === /*index*/
        ctx[15]
      )
    }
  });
  return {
    c() {
      create_component(tabinput.$$.fragment);
      t = space();
    },
    m(target, anchor) {
      mount_component(tabinput, target, anchor);
      insert(target, t, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const tabinput_changes = {};
      if (dirty & /*tempTabs*/
      16)
        tabinput_changes.element = /*tab*/
        ctx2[13];
      if (dirty & /*shouldTakeFocusIndex*/
      8)
        tabinput_changes.shouldTakeFocus = /*shouldTakeFocusIndex*/
        ctx2[3] === /*index*/
        ctx2[15];
      tabinput.$set(tabinput_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(tabinput.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(tabinput.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
      destroy_component(tabinput, detaching);
    }
  };
}
function create_each_block$5(ctx) {
  let draggableitem;
  let current;
  draggableitem = new DraggableItem({
    props: {
      key: "tabLinks",
      onArrayUpdate: (
        /*handleArrayUpdate*/
        ctx[6]
      ),
      isDragEnabled: (
        /*isDragEnabled*/
        ctx[1]
      ),
      dataArray: (
        /*$tabs*/
        ctx[2]
      ),
      index: (
        /*index*/
        ctx[15]
      ),
      $$slots: { default: [create_default_slot_3$3] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(draggableitem.$$.fragment);
    },
    m(target, anchor) {
      mount_component(draggableitem, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const draggableitem_changes = {};
      if (dirty & /*isDragEnabled*/
      2)
        draggableitem_changes.isDragEnabled = /*isDragEnabled*/
        ctx2[1];
      if (dirty & /*$tabs*/
      4)
        draggableitem_changes.dataArray = /*$tabs*/
        ctx2[2];
      if (dirty & /*$$scope, tempTabs, shouldTakeFocusIndex*/
      65560) {
        draggableitem_changes.$$scope = { dirty, ctx: ctx2 };
      }
      draggableitem.$set(draggableitem_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(draggableitem.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(draggableitem.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(draggableitem, detaching);
    }
  };
}
function create_default_slot_2$3(ctx) {
  let each_1_anchor;
  let current;
  let each_value = ensure_array_like(
    /*tempTabs*/
    ctx[4]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$5(get_each_context$5(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  return {
    c() {
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      each_1_anchor = empty();
    },
    m(target, anchor) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(target, anchor);
        }
      }
      insert(target, each_1_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty & /*handleArrayUpdate, isDragEnabled, $tabs, handleUpdate, tempTabs, shouldTakeFocusIndex*/
      350) {
        each_value = ensure_array_like(
          /*tempTabs*/
          ctx2[4]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$5(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block$5(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(each_1_anchor.parentNode, each_1_anchor);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(each_1_anchor);
      }
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_default_slot_1$5(ctx) {
  let t;
  return {
    c() {
      t = text("save");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot$6(ctx) {
  let t;
  return {
    c() {
      t = text("cancel");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_fragment$c(ctx) {
  let component;
  let draggablelist;
  let t0;
  let textfield;
  let t1;
  let div;
  let button0;
  let t2;
  let button1;
  let current;
  draggablelist = new DraggableList({
    props: {
      key: "tabLinks",
      $$slots: { default: [create_default_slot_2$3] },
      $$scope: { ctx }
    }
  });
  textfield = new TextField({
    props: {
      isPlaceholderInput: true,
      placeholder: "new tab name",
      onInput: (
        /*handlePlaceholderInput*/
        ctx[9]
      )
    }
  });
  button0 = new Button({
    props: {
      onClick: (
        /*handleTabSave*/
        ctx[7]
      ),
      $$slots: { default: [create_default_slot_1$5] },
      $$scope: { ctx }
    }
  });
  button1 = new Button({
    props: {
      variant: "secondary",
      onClick: (
        /*handleCancel*/
        ctx[10]
      ),
      $$slots: { default: [create_default_slot$6] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      component = element("component");
      create_component(draggablelist.$$.fragment);
      t0 = space();
      create_component(textfield.$$.fragment);
      t1 = space();
      div = element("div");
      create_component(button0.$$.fragment);
      t2 = space();
      create_component(button1.$$.fragment);
      attr(div, "class", "button-container svelte-11wgxo7");
    },
    m(target, anchor) {
      insert(target, component, anchor);
      mount_component(draggablelist, component, null);
      append(component, t0);
      mount_component(textfield, component, null);
      append(component, t1);
      append(component, div);
      mount_component(button0, div, null);
      append(div, t2);
      mount_component(button1, div, null);
      current = true;
    },
    p(ctx2, [dirty]) {
      const draggablelist_changes = {};
      if (dirty & /*$$scope, tempTabs, isDragEnabled, $tabs, shouldTakeFocusIndex*/
      65566) {
        draggablelist_changes.$$scope = { dirty, ctx: ctx2 };
      }
      draggablelist.$set(draggablelist_changes);
      const button0_changes = {};
      if (dirty & /*$$scope*/
      65536) {
        button0_changes.$$scope = { dirty, ctx: ctx2 };
      }
      button0.$set(button0_changes);
      const button1_changes = {};
      if (dirty & /*$$scope*/
      65536) {
        button1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      button1.$set(button1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(draggablelist.$$.fragment, local);
      transition_in(textfield.$$.fragment, local);
      transition_in(button0.$$.fragment, local);
      transition_in(button1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(draggablelist.$$.fragment, local);
      transition_out(textfield.$$.fragment, local);
      transition_out(button0.$$.fragment, local);
      transition_out(button1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(component);
      }
      destroy_component(draggablelist);
      destroy_component(textfield);
      destroy_component(button0);
      destroy_component(button1);
    }
  };
}
function instance$a($$self, $$props, $$invalidate) {
  let tempTabs;
  let $layerConfig;
  let $tabs, $$unsubscribe_tabs = noop, $$subscribe_tabs = () => ($$unsubscribe_tabs(), $$unsubscribe_tabs = subscribe(tabs, ($$value) => $$invalidate(2, $tabs = $$value)), tabs);
  $$self.$$.on_destroy.push(() => $$unsubscribe_tabs());
  let { tabs } = $$props;
  $$subscribe_tabs();
  let { isDragEnabled = false } = $$props;
  let shouldTakeFocusIndex;
  const layerConfig = getLayerConfig();
  component_subscribe($$self, layerConfig, (value) => $$invalidate(11, $layerConfig = value));
  function handleArrayUpdate(tabs2) {
    $$invalidate(4, tempTabs = tabs2);
  }
  function handleTabSave() {
    set_store_value(tabs, $tabs = tempTabs, $tabs);
    localStorage.setItem("appContent", JSON.stringify($tabs));
    handleCancel();
  }
  function handleUpdate(event, index2) {
    $$invalidate(4, tempTabs[index2][event.currentTarget.name] = event.currentTarget.value, tempTabs);
  }
  function handlePlaceholderInput(event) {
    const input = event.target;
    const firstLetterOfInput = input.value;
    tempTabs.push({ title: "", cards: [], links: [] });
    $$invalidate(4, tempTabs[tempTabs.length - 1].title = firstLetterOfInput, tempTabs);
    input.value = "";
    $$invalidate(3, shouldTakeFocusIndex = tempTabs.length - 1);
  }
  function handleCancel() {
    set_store_value(layerConfig, $layerConfig = { ...$layerConfig, activate: false }, $layerConfig);
  }
  $$self.$$set = ($$props2) => {
    if ("tabs" in $$props2)
      $$subscribe_tabs($$invalidate(0, tabs = $$props2.tabs));
    if ("isDragEnabled" in $$props2)
      $$invalidate(1, isDragEnabled = $$props2.isDragEnabled);
  };
  $$self.$$.update = () => {
    if ($$self.$$.dirty & /*$tabs*/
    4) {
      $$invalidate(4, tempTabs = structuredClone($tabs));
    }
  };
  return [
    tabs,
    isDragEnabled,
    $tabs,
    shouldTakeFocusIndex,
    tempTabs,
    layerConfig,
    handleArrayUpdate,
    handleTabSave,
    handleUpdate,
    handlePlaceholderInput,
    handleCancel
  ];
}
class ManageTabsDrawer extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$a, create_fragment$c, safe_not_equal, { tabs: 0, isDragEnabled: 1 });
  }
}
const CopyIcon_svelte_svelte_type_style_lang = "";
function create_fragment$b(ctx) {
  let svg;
  let defs;
  let g;
  let path0;
  let path1;
  let path2;
  let path3;
  let path4;
  let path5;
  let path6;
  return {
    c() {
      svg = svg_element("svg");
      defs = svg_element("defs");
      g = svg_element("g");
      path0 = svg_element("path");
      path1 = svg_element("path");
      path2 = svg_element("path");
      path3 = svg_element("path");
      path4 = svg_element("path");
      path5 = svg_element("path");
      path6 = svg_element("path");
      attr(path0, "d", "M278.312 207.938L278.312 939.844L910.125 939.844L910.125 207.938L278.312 207.938ZM348.312 277.938L840.125 277.938L840.125 869.844L348.312 869.844C348.312 809.746 348.313 338.035 348.312 277.938Z");
      attr(path0, "fill-rule", "nonzero");
      attr(path0, "opacity", "1");
      attr(path0, "stroke", "none");
      attr(path0, "class", "svelte-1pifc3b");
      attr(path1, "d", "M409.023 338.978L779.423 338.978L779.423 387.268L409.023 387.268L409.023 338.978Z");
      attr(path1, "fill-rule", "nonzero");
      attr(path1, "opacity", "1");
      attr(path1, "stroke", "none");
      attr(path1, "class", "svelte-1pifc3b");
      attr(path2, "d", "M409.023 444.763L779.423 444.763L779.423 493.054L409.023 493.054L409.023 444.763Z");
      attr(path2, "fill-rule", "nonzero");
      attr(path2, "opacity", "1");
      attr(path2, "stroke", "none");
      attr(path2, "class", "svelte-1pifc3b");
      attr(path3, "d", "M409.023 552.545L779.423 552.545L779.423 600.835L409.023 600.835L409.023 552.545Z");
      attr(path3, "fill-rule", "nonzero");
      attr(path3, "opacity", "1");
      attr(path3, "stroke", "none");
      attr(path3, "class", "svelte-1pifc3b");
      attr(path4, "d", "M409.023 658.337L779.423 658.337L779.423 706.628L409.023 706.628L409.023 658.337Z");
      attr(path4, "fill-rule", "nonzero");
      attr(path4, "opacity", "1");
      attr(path4, "stroke", "none");
      attr(path4, "class", "svelte-1pifc3b");
      attr(path5, "d", "M409.023 760.51L779.423 760.51L779.423 808.8L409.023 808.8L409.023 760.51Z");
      attr(path5, "fill-rule", "nonzero");
      attr(path5, "opacity", "1");
      attr(path5, "stroke", "none");
      attr(path5, "class", "svelte-1pifc3b");
      attr(path6, "d", "M729.289 33.447L719.289 33.5095C710.289 33.5798 692.289 33.7205 683.289 33.7908C536.961 33.7908 244.398 33.7908 98.1015 33.7908L88.1015 33.7908L88.1015 43.7908C88.1015 48.7908 88.1015 56.5685 88.1015 63.7908L88.0077 63.7908L88.0077 73.7908C88.0077 227.939 88.0077 536.236 88.0077 690.385C88.0077 695.838 88.0077 706.744 88.0077 712.197L88.0077 712.26L88.0077 712.322C88.0702 717.642 88.1952 728.283 88.2577 733.603C88.3046 737.83 88.3984 746.283 88.4452 750.51L88.5702 760.51L98.5702 760.385C120 760.135 162.859 759.634 184.289 759.385L194.289 759.26L194.164 749.26C193.984 734.26 193.625 704.259 193.445 689.26L193.32 679.26L183.32 679.385C179.492 679.432 173.67 679.502 168.008 679.572C168.008 533.323 168.008 259.982 168.008 113.791C293.174 113.791 524.714 113.791 649.851 113.791C649.893 119.317 649.948 124.994 649.976 128.728L650.039 138.728L660.039 138.666C675.039 138.556 705.039 138.338 720.039 138.228L730.039 138.166L729.976 128.166C729.82 106.986 729.508 64.6267 729.351 43.447L729.289 33.447Z");
      attr(path6, "fill-rule", "nonzero");
      attr(path6, "opacity", "1");
      attr(path6, "stroke", "none");
      attr(path6, "class", "svelte-1pifc3b");
      attr(g, "id", "Layer-1");
      attr(svg, "viewBox", "0 0 1024 1024");
      attr(svg, "width", "2.4rem");
      attr(svg, "xml:space", "preserve");
      attr(svg, "xmlns", "http://www.w3.org/2000/svg");
      attr(svg, "class", "svelte-1pifc3b");
    },
    m(target, anchor) {
      insert(target, svg, anchor);
      append(svg, defs);
      append(svg, g);
      append(g, path0);
      append(g, path1);
      append(g, path2);
      append(g, path3);
      append(g, path4);
      append(g, path5);
      append(g, path6);
    },
    p: noop,
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(svg);
      }
    }
  };
}
class CopyIcon extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, null, create_fragment$b, safe_not_equal, {});
  }
}
const RestoreIcon_svelte_svelte_type_style_lang = "";
function create_fragment$a(ctx) {
  let svg;
  let path0;
  let path1;
  let path2;
  let path3;
  return {
    c() {
      svg = svg_element("svg");
      path0 = svg_element("path");
      path1 = svg_element("path");
      path2 = svg_element("path");
      path3 = svg_element("path");
      attr(path0, "d", "M336.876 576.639L360.799 435L384.873 576.679L524.986 598.726L384.794 623.816L360.435 766.109L337.566 623.573L195 598.017L336.876 576.639Z");
      attr(path0, "fill-rule", "nonzero");
      attr(path0, "opacity", "1");
      attr(path0, "stroke", "none");
      attr(path0, "class", "svelte-131cm5t");
      attr(path1, "d", "M651.706 687.154L671.635 570.725L691.174 687.273L806.351 705.657L691.023 726.035L670.735 843L652.188 725.749L535 704.475L651.706 687.154Z");
      attr(path1, "fill-rule", "nonzero");
      attr(path1, "opacity", "1");
      attr(path1, "stroke", "none");
      attr(path1, "class", "svelte-131cm5t");
      attr(path2, "d", "M549.487 343.554L581.085 149L615.345 343.193L807.788 372.23L615.644 407.871L583.454 603.326L550.84 407.948L355 374.116L549.487 343.554Z");
      attr(path2, "fill-rule", "nonzero");
      attr(path2, "opacity", "1");
      attr(path2, "stroke", "none");
      attr(path2, "class", "svelte-131cm5t");
      attr(path3, "d", "M526.281 40C354.634 40 204.591 132.012 122.469 269.344L103.688 234.344L45.7188 265.469L119.844 403.625L121.656 402.656L122.312 403.875L260.469 329.75L229.344 271.781L182.844 296.719C254.274 182.14 381.321 105.781 526.281 105.781C749.72 105.781 930.844 286.936 930.844 510.375C930.844 733.814 749.72 914.969 526.281 914.969C397.338 914.969 282.555 854.559 208.469 760.594L128.062 760.594C211.325 892.801 358.502 980.75 526.281 980.75C786.058 980.75 996.656 770.152 996.656 510.375C996.656 250.598 786.058 40 526.281 40Z");
      attr(path3, "fill-rule", "nonzero");
      attr(path3, "opacity", "1");
      attr(path3, "stroke", "none");
      attr(path3, "class", "svelte-131cm5t");
      attr(svg, "height", "100%");
      attr(svg, "stroke-miterlimit", "10");
      set_style(svg, "fill-rule", "nonzero");
      set_style(svg, "clip-rule", "evenodd");
      set_style(svg, "stroke-linecap", "round");
      set_style(svg, "stroke-linejoin", "round");
      attr(svg, "viewBox", "0 0 1024 1024");
      attr(svg, "width", "2.4rem");
      attr(svg, "xml:space", "preserve");
      attr(svg, "xmlns", "http://www.w3.org/2000/svg");
    },
    m(target, anchor) {
      insert(target, svg, anchor);
      append(svg, path0);
      append(svg, path1);
      append(svg, path2);
      append(svg, path3);
    },
    p: noop,
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(svg);
      }
    }
  };
}
class RestoreIcon extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, null, create_fragment$a, safe_not_equal, {});
  }
}
const RadioGroup_svelte_svelte_type_style_lang = "";
function get_each_context$4(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[6] = list[i];
  return child_ctx;
}
function create_each_block$4(ctx) {
  let label;
  let input;
  let input_checked_value;
  let input_value_value;
  let value_has_changed = false;
  let t0;
  let t1_value = (
    /*option*/
    ctx[6].label + ""
  );
  let t1;
  let t2;
  let binding_group;
  let mounted;
  let dispose;
  binding_group = init_binding_group(
    /*$$binding_groups*/
    ctx[5][0]
  );
  return {
    c() {
      label = element("label");
      input = element("input");
      t0 = space();
      t1 = text(t1_value);
      t2 = space();
      attr(input, "name", "websiteOptions");
      attr(input, "type", "radio");
      input.checked = input_checked_value = /*option*/
      ctx[6].value === /*selectedValue*/
      ctx[0];
      input.__value = input_value_value = /*option*/
      ctx[6].value;
      set_input_value(input, input.__value);
      attr(input, "class", "svelte-rf8o6e");
      attr(label, "class", "radio-label svelte-rf8o6e");
      binding_group.p(input);
    },
    m(target, anchor) {
      insert(target, label, anchor);
      append(label, input);
      input.checked = input.__value === /*selectedValue*/
      ctx[0];
      append(label, t0);
      append(label, t1);
      append(label, t2);
      if (!mounted) {
        dispose = [
          listen(input, "change", function() {
            if (is_function(
              /*onchange*/
              ctx[3]
            ))
              ctx[3].apply(this, arguments);
          }),
          listen(
            input,
            "change",
            /*input_change_handler*/
            ctx[4]
          )
        ];
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      if (dirty & /*options, selectedValue*/
      3 && input_checked_value !== (input_checked_value = /*option*/
      ctx[6].value === /*selectedValue*/
      ctx[0])) {
        input.checked = input_checked_value;
      }
      if (dirty & /*options*/
      2 && input_value_value !== (input_value_value = /*option*/
      ctx[6].value)) {
        input.__value = input_value_value;
        set_input_value(input, input.__value);
        value_has_changed = true;
      }
      if (value_has_changed || dirty & /*selectedValue, options*/
      3) {
        input.checked = input.__value === /*selectedValue*/
        ctx[0];
      }
      if (dirty & /*options*/
      2 && t1_value !== (t1_value = /*option*/
      ctx[6].label + ""))
        set_data(t1, t1_value);
    },
    d(detaching) {
      if (detaching) {
        detach(label);
      }
      binding_group.r();
      mounted = false;
      run_all(dispose);
    }
  };
}
function create_fragment$9(ctx) {
  let fieldset;
  let legend_1;
  let t0;
  let t1;
  let each_value = ensure_array_like(
    /*options*/
    ctx[1]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$4(get_each_context$4(ctx, each_value, i));
  }
  return {
    c() {
      fieldset = element("fieldset");
      legend_1 = element("legend");
      t0 = text(
        /*legend*/
        ctx[2]
      );
      t1 = space();
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      attr(fieldset, "class", "svelte-rf8o6e");
    },
    m(target, anchor) {
      insert(target, fieldset, anchor);
      append(fieldset, legend_1);
      append(legend_1, t0);
      append(fieldset, t1);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(fieldset, null);
        }
      }
    },
    p(ctx2, [dirty]) {
      if (dirty & /*legend*/
      4)
        set_data(
          t0,
          /*legend*/
          ctx2[2]
        );
      if (dirty & /*options, selectedValue, onchange*/
      11) {
        each_value = ensure_array_like(
          /*options*/
          ctx2[1]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$4(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
          } else {
            each_blocks[i] = create_each_block$4(child_ctx);
            each_blocks[i].c();
            each_blocks[i].m(fieldset, null);
          }
        }
        for (; i < each_blocks.length; i += 1) {
          each_blocks[i].d(1);
        }
        each_blocks.length = each_value.length;
      }
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(fieldset);
      }
      destroy_each(each_blocks, detaching);
    }
  };
}
function instance$9($$self, $$props, $$invalidate) {
  let { options } = $$props;
  let { legend } = $$props;
  let { onchange } = $$props;
  let { selectedValue = 0 } = $$props;
  const $$binding_groups = [[]];
  function input_change_handler() {
    selectedValue = this.__value;
    $$invalidate(0, selectedValue);
  }
  $$self.$$set = ($$props2) => {
    if ("options" in $$props2)
      $$invalidate(1, options = $$props2.options);
    if ("legend" in $$props2)
      $$invalidate(2, legend = $$props2.legend);
    if ("onchange" in $$props2)
      $$invalidate(3, onchange = $$props2.onchange);
    if ("selectedValue" in $$props2)
      $$invalidate(0, selectedValue = $$props2.selectedValue);
  };
  return [
    selectedValue,
    options,
    legend,
    onchange,
    input_change_handler,
    $$binding_groups
  ];
}
class RadioGroup extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$9, create_fragment$9, safe_not_equal, {
      options: 1,
      legend: 2,
      onchange: 3,
      selectedValue: 0
    });
  }
}
const ToggleSwitch_svelte_svelte_type_style_lang = "";
function create_fragment$8(ctx) {
  let button;
  let span1;
  let span2;
  let t1;
  let mounted;
  let dispose;
  return {
    c() {
      button = element("button");
      span1 = element("span");
      span1.innerHTML = `<span class="slider svelte-tsav2f"></span> `;
      span2 = element("span");
      t1 = text(
        /*label*/
        ctx[0]
      );
      attr(span1, "class", "switch svelte-tsav2f");
      attr(span2, "class", "label svelte-tsav2f");
      attr(button, "type", "button");
      attr(
        button,
        "aria-pressed",
        /*toggled*/
        ctx[1]
      );
      attr(button, "class", "svelte-tsav2f");
      toggle_class(
        button,
        "toggled",
        /*toggled*/
        ctx[1]
      );
    },
    m(target, anchor) {
      insert(target, button, anchor);
      append(button, span1);
      append(button, span2);
      append(span2, t1);
      if (!mounted) {
        dispose = listen(
          button,
          "click",
          /*onToggle*/
          ctx[2]
        );
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      if (dirty & /*label*/
      1)
        set_data(
          t1,
          /*label*/
          ctx2[0]
        );
      if (dirty & /*toggled*/
      2) {
        attr(
          button,
          "aria-pressed",
          /*toggled*/
          ctx2[1]
        );
      }
      if (dirty & /*toggled*/
      2) {
        toggle_class(
          button,
          "toggled",
          /*toggled*/
          ctx2[1]
        );
      }
    },
    i: noop,
    o: noop,
    d(detaching) {
      if (detaching) {
        detach(button);
      }
      mounted = false;
      dispose();
    }
  };
}
function instance$8($$self, $$props, $$invalidate) {
  let { label = "" } = $$props;
  let { value = false } = $$props;
  let toggled = value;
  let { onchange } = $$props;
  function onToggle() {
    $$invalidate(1, toggled = !toggled);
    onchange(toggled);
  }
  $$self.$$set = ($$props2) => {
    if ("label" in $$props2)
      $$invalidate(0, label = $$props2.label);
    if ("value" in $$props2)
      $$invalidate(3, value = $$props2.value);
    if ("onchange" in $$props2)
      $$invalidate(4, onchange = $$props2.onchange);
  };
  return [label, toggled, onToggle, value, onchange];
}
class ToggleSwitch extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$8, create_fragment$8, safe_not_equal, { label: 0, value: 3, onchange: 4 });
  }
}
const SettingsDrawer_svelte_svelte_type_style_lang = "";
function create_default_slot_1$4(ctx) {
  let copyicon;
  let current;
  copyicon = new CopyIcon({});
  return {
    c() {
      create_component(copyicon.$$.fragment);
    },
    m(target, anchor) {
      mount_component(copyicon, target, anchor);
      current = true;
    },
    i(local) {
      if (current)
        return;
      transition_in(copyicon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(copyicon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(copyicon, detaching);
    }
  };
}
function create_default_slot$5(ctx) {
  let restoreicon;
  let t;
  let current;
  restoreicon = new RestoreIcon({});
  return {
    c() {
      create_component(restoreicon.$$.fragment);
      t = text("Restore");
    },
    m(target, anchor) {
      mount_component(restoreicon, target, anchor);
      insert(target, t, anchor);
      current = true;
    },
    i(local) {
      if (current)
        return;
      transition_in(restoreicon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(restoreicon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
      destroy_component(restoreicon, detaching);
    }
  };
}
function create_fragment$7(ctx) {
  var _a;
  let section;
  let h2;
  let t1;
  let toggleswitch;
  let t2;
  let radiogroup;
  let t3;
  let label0;
  let t4;
  let input;
  let input_value_value;
  let t5;
  let div;
  let h30;
  let t7;
  let p;
  let t9;
  let button0;
  let t10;
  let h31;
  let t12;
  let label1;
  let span;
  let t14;
  let textarea;
  let t15;
  let button1;
  let current;
  let mounted;
  let dispose;
  toggleswitch = new ToggleSwitch({
    props: {
      label: "hide edit options",
      onchange: (
        /*editableHandler*/
        ctx[8]
      ),
      value: (
        /*$settings*/
        ctx[3].editable
      )
    }
  });
  radiogroup = new RadioGroup({
    props: {
      selectedValue: (
        /*$settings*/
        ctx[3].defaultTab ?? 0
      ),
      onchange: (
        /*defaultTabHandler*/
        ctx[7]
      ),
      options: (
        /*$tabs*/
        (_a = ctx[2]) == null ? void 0 : _a.map(func)
      ),
      legend: "Default tab"
    }
  });
  button0 = new Button({
    props: {
      onClick: (
        /*copyHandler*/
        ctx[5]
      ),
      $$slots: { default: [create_default_slot_1$4] },
      $$scope: { ctx }
    }
  });
  button1 = new Button({
    props: {
      onClick: (
        /*changeAppContentHandler*/
        ctx[9]
      ),
      $$slots: { default: [create_default_slot$5] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      section = element("section");
      h2 = element("h2");
      h2.textContent = "Settings";
      t1 = space();
      create_component(toggleswitch.$$.fragment);
      t2 = space();
      create_component(radiogroup.$$.fragment);
      t3 = space();
      label0 = element("label");
      t4 = text("chose accent color\n    ");
      input = element("input");
      t5 = space();
      div = element("div");
      h30 = element("h3");
      h30.textContent = "JSON backup";
      t7 = space();
      p = element("p");
      p.textContent = "Clicking the button will copy the data used in this application. You can then just copy and\n      paste it into a text file or JSON file type to ensure you don't lose all your links";
      t9 = space();
      create_component(button0.$$.fragment);
      t10 = space();
      h31 = element("h3");
      h31.textContent = "Restore";
      t12 = space();
      label1 = element("label");
      span = element("span");
      span.textContent = "Paste the information you've backed up previously into this text field to restore";
      t14 = space();
      textarea = element("textarea");
      t15 = space();
      create_component(button1.$$.fragment);
      attr(input, "type", "color");
      input.value = input_value_value = /*$settings*/
      ctx[3].color;
      attr(label0, "class", "svelte-1xl56xp");
      attr(textarea, "rows", "7");
      attr(textarea, "class", "svelte-1xl56xp");
      attr(label1, "class", "svelte-1xl56xp");
      attr(section, "class", "svelte-1xl56xp");
    },
    m(target, anchor) {
      insert(target, section, anchor);
      append(section, h2);
      append(section, t1);
      mount_component(toggleswitch, section, null);
      append(section, t2);
      mount_component(radiogroup, section, null);
      append(section, t3);
      append(section, label0);
      append(label0, t4);
      append(label0, input);
      append(section, t5);
      append(section, div);
      append(div, h30);
      append(div, t7);
      append(div, p);
      append(div, t9);
      mount_component(button0, div, null);
      append(section, t10);
      append(section, h31);
      append(section, t12);
      append(section, label1);
      append(label1, span);
      append(label1, t14);
      append(label1, textarea);
      set_input_value(
        textarea,
        /*jsonData*/
        ctx[1]
      );
      append(label1, t15);
      mount_component(button1, label1, null);
      current = true;
      if (!mounted) {
        dispose = [
          listen(
            input,
            "change",
            /*accentColorHandler*/
            ctx[6]
          ),
          listen(
            textarea,
            "input",
            /*textarea_input_handler*/
            ctx[10]
          )
        ];
        mounted = true;
      }
    },
    p(ctx2, [dirty]) {
      var _a2;
      const toggleswitch_changes = {};
      if (dirty & /*$settings*/
      8)
        toggleswitch_changes.value = /*$settings*/
        ctx2[3].editable;
      toggleswitch.$set(toggleswitch_changes);
      const radiogroup_changes = {};
      if (dirty & /*$settings*/
      8)
        radiogroup_changes.selectedValue = /*$settings*/
        ctx2[3].defaultTab ?? 0;
      if (dirty & /*$tabs*/
      4)
        radiogroup_changes.options = /*$tabs*/
        (_a2 = ctx2[2]) == null ? void 0 : _a2.map(func);
      radiogroup.$set(radiogroup_changes);
      if (!current || dirty & /*$settings*/
      8 && input_value_value !== (input_value_value = /*$settings*/
      ctx2[3].color)) {
        input.value = input_value_value;
      }
      const button0_changes = {};
      if (dirty & /*$$scope*/
      2048) {
        button0_changes.$$scope = { dirty, ctx: ctx2 };
      }
      button0.$set(button0_changes);
      if (dirty & /*jsonData*/
      2) {
        set_input_value(
          textarea,
          /*jsonData*/
          ctx2[1]
        );
      }
      const button1_changes = {};
      if (dirty & /*$$scope*/
      2048) {
        button1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      button1.$set(button1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(toggleswitch.$$.fragment, local);
      transition_in(radiogroup.$$.fragment, local);
      transition_in(button0.$$.fragment, local);
      transition_in(button1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(toggleswitch.$$.fragment, local);
      transition_out(radiogroup.$$.fragment, local);
      transition_out(button0.$$.fragment, local);
      transition_out(button1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(section);
      }
      destroy_component(toggleswitch);
      destroy_component(radiogroup);
      destroy_component(button0);
      destroy_component(button1);
      mounted = false;
      run_all(dispose);
    }
  };
}
const func = (tab, index2) => ({ label: tab.title, value: index2 });
function instance$7($$self, $$props, $$invalidate) {
  let $tabs, $$unsubscribe_tabs = noop, $$subscribe_tabs = () => ($$unsubscribe_tabs(), $$unsubscribe_tabs = subscribe(tabs, ($$value) => $$invalidate(2, $tabs = $$value)), tabs);
  let $settings;
  $$self.$$.on_destroy.push(() => $$unsubscribe_tabs());
  let settings = getSettings();
  component_subscribe($$self, settings, (value) => $$invalidate(3, $settings = value));
  let jsonData;
  let { tabs } = $$props;
  $$subscribe_tabs();
  const copyHandler = () => {
    navigator.clipboard.writeText(JSON.stringify($tabs));
  };
  const accentColorHandler = (event) => {
    console.log(event.currentTarget.value);
    set_store_value(
      settings,
      $settings = {
        ...$settings,
        color: event.currentTarget.value
      },
      $settings
    );
    localStorage.setItem("settings", JSON.stringify($settings));
  };
  const defaultTabHandler = (event) => {
    set_store_value(
      settings,
      $settings = {
        ...$settings,
        defaultTab: parseInt(event.currentTarget.value)
      },
      $settings
    );
    localStorage.setItem("settings", JSON.stringify($settings));
  };
  const editableHandler = (editable) => {
    set_store_value(settings, $settings = { ...$settings, editable }, $settings);
    localStorage.setItem("settings", JSON.stringify($settings));
  };
  const changeAppContentHandler = (event) => {
    if (event.currentTarget.value !== "") {
      return;
    }
    set_store_value(tabs, $tabs = JSON.parse(jsonData), $tabs);
    localStorage.setItem("appContent", jsonData);
  };
  function textarea_input_handler() {
    jsonData = this.value;
    $$invalidate(1, jsonData);
  }
  $$self.$$set = ($$props2) => {
    if ("tabs" in $$props2)
      $$subscribe_tabs($$invalidate(0, tabs = $$props2.tabs));
  };
  return [
    tabs,
    jsonData,
    $tabs,
    $settings,
    settings,
    copyHandler,
    accentColorHandler,
    defaultTabHandler,
    editableHandler,
    changeAppContentHandler,
    textarea_input_handler
  ];
}
class SettingsDrawer extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$7, create_fragment$7, safe_not_equal, { tabs: 0 });
  }
}
function create_fragment$6(ctx) {
  let div0;
  let textfield0;
  let t;
  let div1;
  let textfield1;
  let current;
  textfield0 = new TextField({
    props: {
      value: (
        /*element*/
        ctx[0].label
      ),
      onChange: (
        /*func*/
        ctx[4]
      ),
      name: "label",
      label: "label",
      shouldTakeFocus: (
        /*shouldTakeFocus*/
        ctx[2]
      )
    }
  });
  textfield1 = new TextField({
    props: {
      value: (
        /*element*/
        ctx[0].url
      ),
      onChange: (
        /*func_1*/
        ctx[5]
      ),
      name: "url",
      label: "url"
    }
  });
  return {
    c() {
      div0 = element("div");
      create_component(textfield0.$$.fragment);
      t = space();
      div1 = element("div");
      create_component(textfield1.$$.fragment);
    },
    m(target, anchor) {
      insert(target, div0, anchor);
      mount_component(textfield0, div0, null);
      insert(target, t, anchor);
      insert(target, div1, anchor);
      mount_component(textfield1, div1, null);
      current = true;
    },
    p(ctx2, [dirty]) {
      const textfield0_changes = {};
      if (dirty & /*element*/
      1)
        textfield0_changes.value = /*element*/
        ctx2[0].label;
      if (dirty & /*onUpdateLink, index*/
      10)
        textfield0_changes.onChange = /*func*/
        ctx2[4];
      if (dirty & /*shouldTakeFocus*/
      4)
        textfield0_changes.shouldTakeFocus = /*shouldTakeFocus*/
        ctx2[2];
      textfield0.$set(textfield0_changes);
      const textfield1_changes = {};
      if (dirty & /*element*/
      1)
        textfield1_changes.value = /*element*/
        ctx2[0].url;
      if (dirty & /*onUpdateLink, index*/
      10)
        textfield1_changes.onChange = /*func_1*/
        ctx2[5];
      textfield1.$set(textfield1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(textfield0.$$.fragment, local);
      transition_in(textfield1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(textfield0.$$.fragment, local);
      transition_out(textfield1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div0);
        detach(t);
        detach(div1);
      }
      destroy_component(textfield0);
      destroy_component(textfield1);
    }
  };
}
function instance$6($$self, $$props, $$invalidate) {
  let { element: element2 } = $$props;
  let { index: index2 } = $$props;
  let { shouldTakeFocus } = $$props;
  let { onUpdateLink } = $$props;
  const func2 = (event) => onUpdateLink(event, index2);
  const func_1 = (event) => onUpdateLink(event, index2);
  $$self.$$set = ($$props2) => {
    if ("element" in $$props2)
      $$invalidate(0, element2 = $$props2.element);
    if ("index" in $$props2)
      $$invalidate(1, index2 = $$props2.index);
    if ("shouldTakeFocus" in $$props2)
      $$invalidate(2, shouldTakeFocus = $$props2.shouldTakeFocus);
    if ("onUpdateLink" in $$props2)
      $$invalidate(3, onUpdateLink = $$props2.onUpdateLink);
  };
  return [element2, index2, shouldTakeFocus, onUpdateLink, func2, func_1];
}
class LinkInput extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$6, create_fragment$6, safe_not_equal, {
      element: 0,
      index: 1,
      shouldTakeFocus: 2,
      onUpdateLink: 3
    });
  }
}
const UpdateCardDrawer_svelte_svelte_type_style_lang = "";
function get_each_context$3(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[13] = list[i];
  child_ctx[15] = i;
  return child_ctx;
}
function create_default_slot_3$2(ctx) {
  let linkinput;
  let current;
  linkinput = new LinkInput({
    props: {
      onUpdateLink: (
        /*handleUpdateLinks*/
        ctx[4]
      ),
      element: (
        /*link*/
        ctx[13]
      ),
      index: (
        /*index*/
        ctx[15]
      ),
      shouldTakeFocus: (
        /*shouldTakeFocusIndex*/
        ctx[1] === /*index*/
        ctx[15]
      )
    }
  });
  return {
    c() {
      create_component(linkinput.$$.fragment);
    },
    m(target, anchor) {
      mount_component(linkinput, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const linkinput_changes = {};
      if (dirty & /*tempCard*/
      1)
        linkinput_changes.element = /*link*/
        ctx2[13];
      if (dirty & /*shouldTakeFocusIndex*/
      2)
        linkinput_changes.shouldTakeFocus = /*shouldTakeFocusIndex*/
        ctx2[1] === /*index*/
        ctx2[15];
      linkinput.$set(linkinput_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(linkinput.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(linkinput.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(linkinput, detaching);
    }
  };
}
function create_each_block$3(ctx) {
  let draggableitem;
  let current;
  draggableitem = new DraggableItem({
    props: {
      key: "tabLinks",
      onArrayUpdate: (
        /*handleArrayUpdate*/
        ctx[8]
      ),
      isDragEnabled: (
        /*isDragEnabled*/
        ctx[3]
      ),
      dataArray: (
        /*tempCard*/
        ctx[0].links
      ),
      index: (
        /*index*/
        ctx[15]
      ),
      $$slots: { default: [create_default_slot_3$2] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(draggableitem.$$.fragment);
    },
    m(target, anchor) {
      mount_component(draggableitem, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const draggableitem_changes = {};
      if (dirty & /*tempCard*/
      1)
        draggableitem_changes.dataArray = /*tempCard*/
        ctx2[0].links;
      if (dirty & /*$$scope, tempCard, shouldTakeFocusIndex*/
      65539) {
        draggableitem_changes.$$scope = { dirty, ctx: ctx2 };
      }
      draggableitem.$set(draggableitem_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(draggableitem.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(draggableitem.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(draggableitem, detaching);
    }
  };
}
function create_default_slot_2$2(ctx) {
  var _a;
  let t;
  let textfield;
  let current;
  let each_value = ensure_array_like(
    /*tempCard*/
    (_a = ctx[0]) == null ? void 0 : _a.links
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$3(get_each_context$3(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  textfield = new TextField({
    props: {
      isPlaceholderInput: true,
      placeholder: "new link name",
      onInput: (
        /*handlePlaceholderInputForLinks*/
        ctx[9]
      )
    }
  });
  return {
    c() {
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      t = space();
      create_component(textfield.$$.fragment);
    },
    m(target, anchor) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(target, anchor);
        }
      }
      insert(target, t, anchor);
      mount_component(textfield, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      var _a2;
      if (dirty & /*handleArrayUpdate, isDragEnabled, tempCard, handleUpdateLinks, shouldTakeFocusIndex*/
      283) {
        each_value = ensure_array_like(
          /*tempCard*/
          (_a2 = ctx2[0]) == null ? void 0 : _a2.links
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$3(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block$3(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(t.parentNode, t);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      transition_in(textfield.$$.fragment, local);
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      transition_out(textfield.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
      destroy_each(each_blocks, detaching);
      destroy_component(textfield, detaching);
    }
  };
}
function create_default_slot_1$3(ctx) {
  let t;
  return {
    c() {
      t = text("save");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot$4(ctx) {
  let t;
  return {
    c() {
      t = text("cancel");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_fragment$5(ctx) {
  var _a;
  let component;
  let textfield;
  let t0;
  let p;
  let t2;
  let draggablelist;
  let t3;
  let div;
  let button0;
  let t4;
  let button1;
  let current;
  textfield = new TextField({
    props: {
      value: (
        /*tempCard*/
        (_a = ctx[0]) == null ? void 0 : _a.title
      ),
      onChange: (
        /*handleTitleInput*/
        ctx[7]
      ),
      name: "label"
    }
  });
  draggablelist = new DraggableList({
    props: {
      key: "tabLinks",
      $$slots: { default: [create_default_slot_2$2] },
      $$scope: { ctx }
    }
  });
  button0 = new Button({
    props: {
      onClick: (
        /*handleSave*/
        ctx[5]
      ),
      $$slots: { default: [create_default_slot_1$3] },
      $$scope: { ctx }
    }
  });
  button1 = new Button({
    props: {
      variant: "secondary",
      onClick: (
        /*handleCancel*/
        ctx[6]
      ),
      $$slots: { default: [create_default_slot$4] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      component = element("component");
      create_component(textfield.$$.fragment);
      t0 = space();
      p = element("p");
      p.textContent = "Changing the order, create new, delete, or edit the links";
      t2 = space();
      create_component(draggablelist.$$.fragment);
      t3 = space();
      div = element("div");
      create_component(button0.$$.fragment);
      t4 = space();
      create_component(button1.$$.fragment);
      attr(div, "class", "button-container svelte-11wgxo7");
    },
    m(target, anchor) {
      insert(target, component, anchor);
      mount_component(textfield, component, null);
      append(component, t0);
      append(component, p);
      append(component, t2);
      mount_component(draggablelist, component, null);
      append(component, t3);
      append(component, div);
      mount_component(button0, div, null);
      append(div, t4);
      mount_component(button1, div, null);
      current = true;
    },
    p(ctx2, [dirty]) {
      var _a2;
      const textfield_changes = {};
      if (dirty & /*tempCard*/
      1)
        textfield_changes.value = /*tempCard*/
        (_a2 = ctx2[0]) == null ? void 0 : _a2.title;
      textfield.$set(textfield_changes);
      const draggablelist_changes = {};
      if (dirty & /*$$scope, tempCard, shouldTakeFocusIndex*/
      65539) {
        draggablelist_changes.$$scope = { dirty, ctx: ctx2 };
      }
      draggablelist.$set(draggablelist_changes);
      const button0_changes = {};
      if (dirty & /*$$scope*/
      65536) {
        button0_changes.$$scope = { dirty, ctx: ctx2 };
      }
      button0.$set(button0_changes);
      const button1_changes = {};
      if (dirty & /*$$scope*/
      65536) {
        button1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      button1.$set(button1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(textfield.$$.fragment, local);
      transition_in(draggablelist.$$.fragment, local);
      transition_in(button0.$$.fragment, local);
      transition_in(button1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(textfield.$$.fragment, local);
      transition_out(draggablelist.$$.fragment, local);
      transition_out(button0.$$.fragment, local);
      transition_out(button1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(component);
      }
      destroy_component(textfield);
      destroy_component(draggablelist);
      destroy_component(button0);
      destroy_component(button1);
    }
  };
}
function instance$5($$self, $$props, $$invalidate) {
  let $layerConfig;
  let { card } = $$props;
  let { onSave } = $$props;
  let layerConfig = getLayerConfig();
  component_subscribe($$self, layerConfig, (value) => $$invalidate(12, $layerConfig = value));
  let tempCard = { ...card };
  let isDragEnabled;
  let shouldTakeFocusIndex;
  onMount(() => {
    if (!card) {
      $$invalidate(10, card = { title: "new card", links: [] });
    }
  });
  function handleUpdateLinks(event, linkIndex) {
    const newLinkArray = [...tempCard.links].map((link, index2) => index2 === linkIndex ? {
      ...tempCard.links[index2],
      [event.currentTarget.name]: event.currentTarget.value
    } : link);
    $$invalidate(0, tempCard = { ...tempCard, links: newLinkArray });
  }
  function handleSave() {
    onSave(tempCard);
    handleCancel();
  }
  function handleCancel() {
    set_store_value(layerConfig, $layerConfig = { ...$layerConfig, activate: false }, $layerConfig);
  }
  function handleTitleInput(event) {
    const currentTarget = event.currentTarget;
    $$invalidate(0, tempCard.title = currentTarget.value, tempCard);
  }
  function handleArrayUpdate(links) {
    $$invalidate(0, tempCard.links = links, tempCard);
  }
  function handlePlaceholderInputForLinks(event) {
    const input = event.target;
    const firstLetterOfInput = input.value;
    $$invalidate(0, tempCard.links = [...tempCard.links, { url: "", label: "" }], tempCard);
    $$invalidate(0, tempCard.links[tempCard.links.length - 1].label = firstLetterOfInput, tempCard);
    input.value = "";
    $$invalidate(1, shouldTakeFocusIndex = tempCard.links.length - 1);
  }
  $$self.$$set = ($$props2) => {
    if ("card" in $$props2)
      $$invalidate(10, card = $$props2.card);
    if ("onSave" in $$props2)
      $$invalidate(11, onSave = $$props2.onSave);
  };
  return [
    tempCard,
    shouldTakeFocusIndex,
    layerConfig,
    isDragEnabled,
    handleUpdateLinks,
    handleSave,
    handleCancel,
    handleTitleInput,
    handleArrayUpdate,
    handlePlaceholderInputForLinks,
    card,
    onSave
  ];
}
class UpdateCardDrawer extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$5, create_fragment$5, safe_not_equal, { card: 10, onSave: 11 });
  }
}
const CardInput_svelte_svelte_type_style_lang = "";
function create_fragment$4(ctx) {
  let div;
  let textfield;
  let current;
  textfield = new TextField({
    props: {
      value: (
        /*element*/
        ctx[1].title
      ),
      onChange: (
        /*func*/
        ctx[4]
      ),
      name: "title",
      shouldTakeFocus: (
        /*shouldTakeFocus*/
        ctx[2]
      )
    }
  });
  return {
    c() {
      div = element("div");
      create_component(textfield.$$.fragment);
      attr(div, "class", "svelte-12417c9");
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(textfield, div, null);
      current = true;
    },
    p(ctx2, [dirty]) {
      const textfield_changes = {};
      if (dirty & /*element*/
      2)
        textfield_changes.value = /*element*/
        ctx2[1].title;
      if (dirty & /*onUpdateCard, index*/
      9)
        textfield_changes.onChange = /*func*/
        ctx2[4];
      if (dirty & /*shouldTakeFocus*/
      4)
        textfield_changes.shouldTakeFocus = /*shouldTakeFocus*/
        ctx2[2];
      textfield.$set(textfield_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(textfield.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(textfield.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(div);
      }
      destroy_component(textfield);
    }
  };
}
function instance$4($$self, $$props, $$invalidate) {
  let { index: index2 } = $$props;
  let { element: element2 } = $$props;
  let { shouldTakeFocus } = $$props;
  let { onUpdateCard } = $$props;
  const func2 = (event) => onUpdateCard(event, index2);
  $$self.$$set = ($$props2) => {
    if ("index" in $$props2)
      $$invalidate(0, index2 = $$props2.index);
    if ("element" in $$props2)
      $$invalidate(1, element2 = $$props2.element);
    if ("shouldTakeFocus" in $$props2)
      $$invalidate(2, shouldTakeFocus = $$props2.shouldTakeFocus);
    if ("onUpdateCard" in $$props2)
      $$invalidate(3, onUpdateCard = $$props2.onUpdateCard);
  };
  return [index2, element2, shouldTakeFocus, onUpdateCard, func2];
}
class CardInput extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$4, create_fragment$4, safe_not_equal, {
      index: 0,
      element: 1,
      shouldTakeFocus: 2,
      onUpdateCard: 3
    });
  }
}
const UpdateGridDrawer_svelte_svelte_type_style_lang = "";
function get_each_context$2(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[17] = list[i];
  child_ctx[19] = i;
  return child_ctx;
}
function get_each_context_1(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[20] = list[i];
  child_ctx[19] = i;
  return child_ctx;
}
function create_default_slot_5(ctx) {
  let linkinput;
  let t;
  let current;
  linkinput = new LinkInput({
    props: {
      onUpdateLink: (
        /*handleUpdate*/
        ctx[9]
      ),
      element: (
        /*link*/
        ctx[20]
      ),
      index: (
        /*index*/
        ctx[19]
      ),
      shouldTakeFocus: (
        /*shouldTakeFocusIndex*/
        ctx[2] === /*index*/
        ctx[19]
      )
    }
  });
  return {
    c() {
      create_component(linkinput.$$.fragment);
      t = space();
    },
    m(target, anchor) {
      mount_component(linkinput, target, anchor);
      insert(target, t, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const linkinput_changes = {};
      if (dirty & /*tempTab*/
      2)
        linkinput_changes.element = /*link*/
        ctx2[20];
      if (dirty & /*shouldTakeFocusIndex*/
      4)
        linkinput_changes.shouldTakeFocus = /*shouldTakeFocusIndex*/
        ctx2[2] === /*index*/
        ctx2[19];
      linkinput.$set(linkinput_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(linkinput.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(linkinput.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
      destroy_component(linkinput, detaching);
    }
  };
}
function create_each_block_1(ctx) {
  let draggableitem;
  let current;
  draggableitem = new DraggableItem({
    props: {
      key: "tabLinks",
      onArrayUpdate: (
        /*handleArrayUpdate*/
        ctx[6]
      ),
      isDragEnabled: (
        /*isDragEnabled*/
        ctx[3]
      ),
      dataArray: (
        /*tempTab*/
        ctx[1].links
      ),
      index: (
        /*index*/
        ctx[19]
      ),
      $$slots: { default: [create_default_slot_5] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(draggableitem.$$.fragment);
    },
    m(target, anchor) {
      mount_component(draggableitem, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const draggableitem_changes = {};
      if (dirty & /*tempTab*/
      2)
        draggableitem_changes.dataArray = /*tempTab*/
        ctx2[1].links;
      if (dirty & /*$$scope, tempTab, shouldTakeFocusIndex*/
      4194310) {
        draggableitem_changes.$$scope = { dirty, ctx: ctx2 };
      }
      draggableitem.$set(draggableitem_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(draggableitem.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(draggableitem.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(draggableitem, detaching);
    }
  };
}
function create_default_slot_4(ctx) {
  var _a;
  let each_1_anchor;
  let current;
  let each_value_1 = ensure_array_like(
    /*tempTab*/
    (_a = ctx[1]) == null ? void 0 : _a.links
  );
  let each_blocks = [];
  for (let i = 0; i < each_value_1.length; i += 1) {
    each_blocks[i] = create_each_block_1(get_each_context_1(ctx, each_value_1, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  return {
    c() {
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      each_1_anchor = empty();
    },
    m(target, anchor) {
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(target, anchor);
        }
      }
      insert(target, each_1_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      var _a2;
      if (dirty & /*handleArrayUpdate, isDragEnabled, tempTab, handleUpdate, shouldTakeFocusIndex*/
      590) {
        each_value_1 = ensure_array_like(
          /*tempTab*/
          (_a2 = ctx2[1]) == null ? void 0 : _a2.links
        );
        let i;
        for (i = 0; i < each_value_1.length; i += 1) {
          const child_ctx = get_each_context_1(ctx2, each_value_1, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block_1(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(each_1_anchor.parentNode, each_1_anchor);
          }
        }
        group_outros();
        for (i = each_value_1.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value_1.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(each_1_anchor);
      }
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_default_slot_3$1(ctx) {
  let cardinput;
  let t;
  let current;
  cardinput = new CardInput({
    props: {
      element: (
        /*card*/
        ctx[17]
      ),
      shouldTakeFocus: (
        /*shouldTakeFocusIndex*/
        ctx[2] === /*index*/
        ctx[19]
      ),
      onUpdateCard: (
        /*handleUpdateCard*/
        ctx[10]
      ),
      index: (
        /*index*/
        ctx[19]
      )
    }
  });
  return {
    c() {
      create_component(cardinput.$$.fragment);
      t = space();
    },
    m(target, anchor) {
      mount_component(cardinput, target, anchor);
      insert(target, t, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const cardinput_changes = {};
      if (dirty & /*tempTab*/
      2)
        cardinput_changes.element = /*card*/
        ctx2[17];
      if (dirty & /*shouldTakeFocusIndex*/
      4)
        cardinput_changes.shouldTakeFocus = /*shouldTakeFocusIndex*/
        ctx2[2] === /*index*/
        ctx2[19];
      cardinput.$set(cardinput_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(cardinput.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(cardinput.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
      destroy_component(cardinput, detaching);
    }
  };
}
function create_each_block$2(ctx) {
  let draggableitem;
  let current;
  draggableitem = new DraggableItem({
    props: {
      key: "cardOrder",
      onArrayUpdate: (
        /*handleCardReorder*/
        ctx[7]
      ),
      isDragEnabled: (
        /*isDragEnabled2*/
        ctx[4]
      ),
      dataArray: (
        /*tempTab*/
        ctx[1].cards
      ),
      index: (
        /*index*/
        ctx[19]
      ),
      $$slots: { default: [create_default_slot_3$1] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      create_component(draggableitem.$$.fragment);
    },
    m(target, anchor) {
      mount_component(draggableitem, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const draggableitem_changes = {};
      if (dirty & /*tempTab*/
      2)
        draggableitem_changes.dataArray = /*tempTab*/
        ctx2[1].cards;
      if (dirty & /*$$scope, tempTab, shouldTakeFocusIndex*/
      4194310) {
        draggableitem_changes.$$scope = { dirty, ctx: ctx2 };
      }
      draggableitem.$set(draggableitem_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(draggableitem.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(draggableitem.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(draggableitem, detaching);
    }
  };
}
function create_default_slot_2$1(ctx) {
  let p;
  let t1;
  let each_1_anchor;
  let current;
  let each_value = ensure_array_like(
    /*tempTab*/
    ctx[1].cards
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$2(get_each_context$2(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  return {
    c() {
      p = element("p");
      p.textContent = "Update grid order or card titles";
      t1 = space();
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      each_1_anchor = empty();
    },
    m(target, anchor) {
      insert(target, p, anchor);
      insert(target, t1, anchor);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(target, anchor);
        }
      }
      insert(target, each_1_anchor, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty & /*handleCardReorder, isDragEnabled2, tempTab, shouldTakeFocusIndex, handleUpdateCard*/
      1174) {
        each_value = ensure_array_like(
          /*tempTab*/
          ctx2[1].cards
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$2(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block$2(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(each_1_anchor.parentNode, each_1_anchor);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(p);
        detach(t1);
        detach(each_1_anchor);
      }
      destroy_each(each_blocks, detaching);
    }
  };
}
function create_default_slot_1$2(ctx) {
  let t;
  return {
    c() {
      t = text("save");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_default_slot$3(ctx) {
  let t;
  return {
    c() {
      t = text("cancel");
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_fragment$3(ctx) {
  let component;
  let p;
  let t1;
  let draggablelist0;
  let t2;
  let textfield0;
  let t3;
  let draggablelist1;
  let t4;
  let textfield1;
  let t5;
  let div;
  let button0;
  let t6;
  let button1;
  let current;
  draggablelist0 = new DraggableList({
    props: {
      key: "tabLinks",
      $$slots: { default: [create_default_slot_4] },
      $$scope: { ctx }
    }
  });
  textfield0 = new TextField({
    props: {
      isPlaceholderInput: true,
      placeholder: "new link name",
      onInput: (
        /*handlePlaceholderInputForLinks*/
        ctx[11]
      )
    }
  });
  draggablelist1 = new DraggableList({
    props: {
      key: "cardOrder",
      $$slots: { default: [create_default_slot_2$1] },
      $$scope: { ctx }
    }
  });
  textfield1 = new TextField({
    props: {
      isPlaceholderInput: true,
      placeholder: "new card name",
      onInput: (
        /*handlePlaceholderInputForCards*/
        ctx[12]
      )
    }
  });
  button0 = new Button({
    props: {
      onClick: (
        /*handleSaveAll*/
        ctx[8]
      ),
      $$slots: { default: [create_default_slot_1$2] },
      $$scope: { ctx }
    }
  });
  button1 = new Button({
    props: {
      variant: "secondary",
      onClick: (
        /*handleCancel*/
        ctx[13]
      ),
      $$slots: { default: [create_default_slot$3] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      component = element("component");
      p = element("p");
      p.textContent = "Update tab links, their order or content";
      t1 = space();
      create_component(draggablelist0.$$.fragment);
      t2 = space();
      create_component(textfield0.$$.fragment);
      t3 = space();
      create_component(draggablelist1.$$.fragment);
      t4 = space();
      create_component(textfield1.$$.fragment);
      t5 = space();
      div = element("div");
      create_component(button0.$$.fragment);
      t6 = space();
      create_component(button1.$$.fragment);
      attr(div, "class", "button-container svelte-11wgxo7");
    },
    m(target, anchor) {
      insert(target, component, anchor);
      append(component, p);
      append(component, t1);
      mount_component(draggablelist0, component, null);
      append(component, t2);
      mount_component(textfield0, component, null);
      append(component, t3);
      mount_component(draggablelist1, component, null);
      append(component, t4);
      mount_component(textfield1, component, null);
      append(component, t5);
      append(component, div);
      mount_component(button0, div, null);
      append(div, t6);
      mount_component(button1, div, null);
      current = true;
    },
    p(ctx2, [dirty]) {
      const draggablelist0_changes = {};
      if (dirty & /*$$scope, tempTab, shouldTakeFocusIndex*/
      4194310) {
        draggablelist0_changes.$$scope = { dirty, ctx: ctx2 };
      }
      draggablelist0.$set(draggablelist0_changes);
      const draggablelist1_changes = {};
      if (dirty & /*$$scope, tempTab, shouldTakeFocusIndex*/
      4194310) {
        draggablelist1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      draggablelist1.$set(draggablelist1_changes);
      const button0_changes = {};
      if (dirty & /*$$scope*/
      4194304) {
        button0_changes.$$scope = { dirty, ctx: ctx2 };
      }
      button0.$set(button0_changes);
      const button1_changes = {};
      if (dirty & /*$$scope*/
      4194304) {
        button1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      button1.$set(button1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(draggablelist0.$$.fragment, local);
      transition_in(textfield0.$$.fragment, local);
      transition_in(draggablelist1.$$.fragment, local);
      transition_in(textfield1.$$.fragment, local);
      transition_in(button0.$$.fragment, local);
      transition_in(button1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(draggablelist0.$$.fragment, local);
      transition_out(textfield0.$$.fragment, local);
      transition_out(draggablelist1.$$.fragment, local);
      transition_out(textfield1.$$.fragment, local);
      transition_out(button0.$$.fragment, local);
      transition_out(button1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(component);
      }
      destroy_component(draggablelist0);
      destroy_component(textfield0);
      destroy_component(draggablelist1);
      destroy_component(textfield1);
      destroy_component(button0);
      destroy_component(button1);
    }
  };
}
function instance$3($$self, $$props, $$invalidate) {
  let $layerConfig;
  let $tabs, $$unsubscribe_tabs = noop, $$subscribe_tabs = () => ($$unsubscribe_tabs(), $$unsubscribe_tabs = subscribe(tabs, ($$value) => $$invalidate(16, $tabs = $$value)), tabs);
  $$self.$$.on_destroy.push(() => $$unsubscribe_tabs());
  let { tabs } = $$props;
  $$subscribe_tabs();
  let { selectedTabIndex } = $$props;
  let isDragEnabled;
  let isDragEnabled2;
  let tempTab = structuredClone($tabs[selectedTabIndex]);
  const layerConfig = getLayerConfig();
  component_subscribe($$self, layerConfig, (value) => $$invalidate(15, $layerConfig = value));
  let shouldTakeFocusIndex;
  function handleArrayUpdate(links) {
    $$invalidate(1, tempTab.links = links, tempTab);
  }
  function handleCardReorder(cards) {
    $$invalidate(1, tempTab.cards = cards, tempTab);
  }
  function handleSaveAll() {
    set_store_value(tabs, $tabs[selectedTabIndex].links = tempTab.links, $tabs);
    localStorage.setItem("appContent", JSON.stringify($tabs));
    set_store_value(tabs, $tabs[selectedTabIndex].cards = tempTab.cards, $tabs);
    localStorage.setItem("appContent", JSON.stringify($tabs));
    handleCancel();
  }
  function handleUpdate(event, index2) {
    $$invalidate(1, tempTab.links[index2][event.currentTarget.name] = event.currentTarget.value, tempTab);
  }
  function handleUpdateCard(event, index2) {
    $$invalidate(1, tempTab.cards[index2][event.currentTarget.name] = event.currentTarget.value, tempTab);
  }
  function handlePlaceholderInputForLinks(event) {
    const input = event.target;
    const firstLetterOfInput = input.value;
    $$invalidate(1, tempTab.links = [...tempTab.links, { url: "", label: "" }], tempTab);
    $$invalidate(1, tempTab.links[tempTab.links.length - 1].label = firstLetterOfInput, tempTab);
    input.value = "";
    $$invalidate(2, shouldTakeFocusIndex = tempTab.links.length - 1);
  }
  function handlePlaceholderInputForCards(event) {
    const input = event.target;
    const firstLetterOfInput = input.value;
    $$invalidate(1, tempTab.cards = [...tempTab.cards, { title: "", links: [] }], tempTab);
    $$invalidate(1, tempTab.cards[tempTab.cards.length - 1].title = firstLetterOfInput, tempTab);
    input.value = "";
    $$invalidate(2, shouldTakeFocusIndex = tempTab.cards.length - 1);
  }
  function handleCancel() {
    set_store_value(layerConfig, $layerConfig = { ...$layerConfig, activate: false }, $layerConfig);
  }
  $$self.$$set = ($$props2) => {
    if ("tabs" in $$props2)
      $$subscribe_tabs($$invalidate(0, tabs = $$props2.tabs));
    if ("selectedTabIndex" in $$props2)
      $$invalidate(14, selectedTabIndex = $$props2.selectedTabIndex);
  };
  return [
    tabs,
    tempTab,
    shouldTakeFocusIndex,
    isDragEnabled,
    isDragEnabled2,
    layerConfig,
    handleArrayUpdate,
    handleCardReorder,
    handleSaveAll,
    handleUpdate,
    handleUpdateCard,
    handlePlaceholderInputForLinks,
    handlePlaceholderInputForCards,
    handleCancel,
    selectedTabIndex
  ];
}
class UpdateGridDrawer extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$3, create_fragment$3, safe_not_equal, { tabs: 0, selectedTabIndex: 14 });
  }
}
const LinksList_svelte_svelte_type_style_lang = "";
function get_each_context$1(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[5] = list[i];
  return child_ctx;
}
function create_default_slot_1$1(ctx) {
  let t_value = (
    /*link*/
    ctx[5].label + ""
  );
  let t;
  return {
    c() {
      t = text(t_value);
    },
    m(target, anchor) {
      insert(target, t, anchor);
    },
    p(ctx2, dirty) {
      if (dirty & /*tabs, selectedTabIndex*/
      3 && t_value !== (t_value = /*link*/
      ctx2[5].label + ""))
        set_data(t, t_value);
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
    }
  };
}
function create_each_block$1(ctx) {
  let li;
  let link_1;
  let div;
  let current;
  link_1 = new Link({
    props: {
      href: (
        /*link*/
        ctx[5].url
      ),
      $$slots: { default: [create_default_slot_1$1] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      li = element("li");
      div = element("div");
      create_component(link_1.$$.fragment);
      set_style(div, "display", "contents");
      set_style(div, "--color-main-background", getComputedStyle(document.documentElement).getPropertyValue("--color-card-background"));
    },
    m(target, anchor) {
      insert(target, li, anchor);
      append(li, div);
      mount_component(link_1, div, null);
      current = true;
    },
    p(ctx2, dirty) {
      const link_1_changes = {};
      if (dirty & /*tabs, selectedTabIndex*/
      3)
        link_1_changes.href = /*link*/
        ctx2[5].url;
      if (dirty & /*$$scope, tabs, selectedTabIndex*/
      259) {
        link_1_changes.$$scope = { dirty, ctx: ctx2 };
      }
      link_1.$set(link_1_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(link_1.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(link_1.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(li);
      }
      destroy_component(link_1);
    }
  };
}
function create_default_slot$2(ctx) {
  let editicon;
  let current;
  editicon = new EditIcon({});
  return {
    c() {
      create_component(editicon.$$.fragment);
    },
    m(target, anchor) {
      mount_component(editicon, target, anchor);
      current = true;
    },
    i(local) {
      if (current)
        return;
      transition_in(editicon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(editicon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(editicon, detaching);
    }
  };
}
function create_fragment$2(ctx) {
  let ul;
  let t0;
  let li;
  let editbutton;
  let t1;
  let button;
  let div;
  let current;
  let each_value = ensure_array_like(
    /*tabs*/
    ctx[0][
      /*selectedTabIndex*/
      ctx[1]
    ].links
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block$1(get_each_context$1(ctx, each_value, i));
  }
  const out = (i) => transition_out(each_blocks[i], 1, 1, () => {
    each_blocks[i] = null;
  });
  editbutton = new EditButton({
    props: {
      onClick: (
        /*openGridDrawer*/
        ctx[3]
      ),
      $$slots: { default: [create_default_slot$2] },
      $$scope: { ctx }
    }
  });
  button = new Button({
    props: { onClick: (
      /*openGridDrawer*/
      ctx[3]
    ) }
  });
  return {
    c() {
      ul = element("ul");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      t0 = space();
      li = element("li");
      create_component(editbutton.$$.fragment);
      t1 = space();
      div = element("div");
      create_component(button.$$.fragment);
      set_style(div, "display", "contents");
      set_style(div, "--color-accent", "transparent");
      attr(li, "class", "edit svelte-wfduee");
      attr(ul, "class", "svelte-wfduee");
    },
    m(target, anchor) {
      insert(target, ul, anchor);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(ul, null);
        }
      }
      append(ul, t0);
      append(ul, li);
      mount_component(editbutton, li, null);
      append(li, t1);
      append(li, div);
      mount_component(button, div, null);
      current = true;
    },
    p(ctx2, [dirty]) {
      if (dirty & /*tabs, selectedTabIndex, getComputedStyle, document*/
      3) {
        each_value = ensure_array_like(
          /*tabs*/
          ctx2[0][
            /*selectedTabIndex*/
            ctx2[1]
          ].links
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context$1(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
            transition_in(each_blocks[i], 1);
          } else {
            each_blocks[i] = create_each_block$1(child_ctx);
            each_blocks[i].c();
            transition_in(each_blocks[i], 1);
            each_blocks[i].m(ul, t0);
          }
        }
        group_outros();
        for (i = each_value.length; i < each_blocks.length; i += 1) {
          out(i);
        }
        check_outros();
      }
      const editbutton_changes = {};
      if (dirty & /*$$scope*/
      256) {
        editbutton_changes.$$scope = { dirty, ctx: ctx2 };
      }
      editbutton.$set(editbutton_changes);
    },
    i(local) {
      if (current)
        return;
      for (let i = 0; i < each_value.length; i += 1) {
        transition_in(each_blocks[i]);
      }
      transition_in(editbutton.$$.fragment, local);
      transition_in(button.$$.fragment, local);
      current = true;
    },
    o(local) {
      each_blocks = each_blocks.filter(Boolean);
      for (let i = 0; i < each_blocks.length; i += 1) {
        transition_out(each_blocks[i]);
      }
      transition_out(editbutton.$$.fragment, local);
      transition_out(button.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(ul);
      }
      destroy_each(each_blocks, detaching);
      destroy_component(editbutton);
      destroy_component(button);
    }
  };
}
function instance$2($$self, $$props, $$invalidate) {
  let $layerConfig;
  const layerConfig = getLayerConfig();
  component_subscribe($$self, layerConfig, (value) => $$invalidate(4, $layerConfig = value));
  let { tabs = [] } = $$props;
  let { selectedTabIndex = 0 } = $$props;
  function openGridDrawer() {
    set_store_value(
      layerConfig,
      $layerConfig = {
        activate: true,
        type: "drawer",
        subtype: "grid"
      },
      $layerConfig
    );
  }
  $$self.$$set = ($$props2) => {
    if ("tabs" in $$props2)
      $$invalidate(0, tabs = $$props2.tabs);
    if ("selectedTabIndex" in $$props2)
      $$invalidate(1, selectedTabIndex = $$props2.selectedTabIndex);
  };
  return [tabs, selectedTabIndex, layerConfig, openGridDrawer];
}
class LinksList extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$2, create_fragment$2, safe_not_equal, { tabs: 0, selectedTabIndex: 1 });
  }
}
const NavBar_svelte_svelte_type_style_lang = "";
function get_each_context(ctx, list, i) {
  const child_ctx = ctx.slice();
  child_ctx[5] = list[i];
  child_ctx[7] = i;
  return child_ctx;
}
function create_each_block(ctx) {
  let li;
  let button;
  let t0_value = (
    /*tab*/
    ctx[5].title + ""
  );
  let t0;
  let t1;
  let mounted;
  let dispose;
  function click_handler() {
    return (
      /*click_handler*/
      ctx[4](
        /*index*/
        ctx[7]
      )
    );
  }
  return {
    c() {
      li = element("li");
      button = element("button");
      t0 = text(t0_value);
      t1 = space();
      attr(button, "class", "svelte-xo2yvq");
      toggle_class(
        button,
        "active",
        /*selectedTabIndex*/
        ctx[1] === /*index*/
        ctx[7]
      );
    },
    m(target, anchor) {
      insert(target, li, anchor);
      append(li, button);
      append(button, t0);
      append(li, t1);
      if (!mounted) {
        dispose = listen(button, "click", click_handler);
        mounted = true;
      }
    },
    p(new_ctx, dirty) {
      ctx = new_ctx;
      if (dirty & /*tabs*/
      1 && t0_value !== (t0_value = /*tab*/
      ctx[5].title + ""))
        set_data(t0, t0_value);
      if (dirty & /*selectedTabIndex*/
      2) {
        toggle_class(
          button,
          "active",
          /*selectedTabIndex*/
          ctx[1] === /*index*/
          ctx[7]
        );
      }
    },
    d(detaching) {
      if (detaching) {
        detach(li);
      }
      mounted = false;
      dispose();
    }
  };
}
function create_default_slot$1(ctx) {
  let editicon;
  let current;
  editicon = new EditIcon({});
  return {
    c() {
      create_component(editicon.$$.fragment);
    },
    m(target, anchor) {
      mount_component(editicon, target, anchor);
      current = true;
    },
    i(local) {
      if (current)
        return;
      transition_in(editicon.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(editicon.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(editicon, detaching);
    }
  };
}
function create_fragment$1(ctx) {
  let nav;
  let ul;
  let t;
  let editbutton;
  let current;
  let each_value = ensure_array_like(
    /*tabs*/
    ctx[0]
  );
  let each_blocks = [];
  for (let i = 0; i < each_value.length; i += 1) {
    each_blocks[i] = create_each_block(get_each_context(ctx, each_value, i));
  }
  editbutton = new EditButton({
    props: {
      onClick: (
        /*onEditTabs*/
        ctx[3]
      ),
      $$slots: { default: [create_default_slot$1] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      nav = element("nav");
      ul = element("ul");
      for (let i = 0; i < each_blocks.length; i += 1) {
        each_blocks[i].c();
      }
      t = space();
      create_component(editbutton.$$.fragment);
      attr(ul, "class", "svelte-xo2yvq");
      attr(nav, "class", "svelte-xo2yvq");
    },
    m(target, anchor) {
      insert(target, nav, anchor);
      append(nav, ul);
      for (let i = 0; i < each_blocks.length; i += 1) {
        if (each_blocks[i]) {
          each_blocks[i].m(ul, null);
        }
      }
      append(nav, t);
      mount_component(editbutton, nav, null);
      current = true;
    },
    p(ctx2, [dirty]) {
      if (dirty & /*selectedTabIndex, onChangeTab, tabs*/
      7) {
        each_value = ensure_array_like(
          /*tabs*/
          ctx2[0]
        );
        let i;
        for (i = 0; i < each_value.length; i += 1) {
          const child_ctx = get_each_context(ctx2, each_value, i);
          if (each_blocks[i]) {
            each_blocks[i].p(child_ctx, dirty);
          } else {
            each_blocks[i] = create_each_block(child_ctx);
            each_blocks[i].c();
            each_blocks[i].m(ul, null);
          }
        }
        for (; i < each_blocks.length; i += 1) {
          each_blocks[i].d(1);
        }
        each_blocks.length = each_value.length;
      }
      const editbutton_changes = {};
      if (dirty & /*onEditTabs*/
      8)
        editbutton_changes.onClick = /*onEditTabs*/
        ctx2[3];
      if (dirty & /*$$scope*/
      256) {
        editbutton_changes.$$scope = { dirty, ctx: ctx2 };
      }
      editbutton.$set(editbutton_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(editbutton.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(editbutton.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(nav);
      }
      destroy_each(each_blocks, detaching);
      destroy_component(editbutton);
    }
  };
}
function instance$1($$self, $$props, $$invalidate) {
  let { tabs = [] } = $$props;
  let { selectedTabIndex = 0 } = $$props;
  let { onChangeTab } = $$props;
  let { onEditTabs } = $$props;
  const click_handler = (index2) => onChangeTab(index2);
  $$self.$$set = ($$props2) => {
    if ("tabs" in $$props2)
      $$invalidate(0, tabs = $$props2.tabs);
    if ("selectedTabIndex" in $$props2)
      $$invalidate(1, selectedTabIndex = $$props2.selectedTabIndex);
    if ("onChangeTab" in $$props2)
      $$invalidate(2, onChangeTab = $$props2.onChangeTab);
    if ("onEditTabs" in $$props2)
      $$invalidate(3, onEditTabs = $$props2.onEditTabs);
  };
  return [tabs, selectedTabIndex, onChangeTab, onEditTabs, click_handler];
}
class NavBar extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance$1, create_fragment$1, safe_not_equal, {
      tabs: 0,
      selectedTabIndex: 1,
      onChangeTab: 2,
      onEditTabs: 3
    });
  }
}
function create_if_block_4(ctx) {
  var _a;
  let linkslist;
  let t;
  let cardslist;
  let current;
  linkslist = new LinksList({
    props: {
      tabs: (
        /*$tabs*/
        ctx[3]
      ),
      selectedTabIndex: (
        /*selectedTabIndex*/
        ctx[0]
      )
    }
  });
  cardslist = new CardsList({
    props: {
      cards: (
        /*$tabs*/
        (_a = ctx[3][
          /*selectedTabIndex*/
          ctx[0]
        ]) == null ? void 0 : _a.cards
      ),
      onChangeSelectedCard: (
        /*handleChangeCard*/
        ctx[9]
      )
    }
  });
  return {
    c() {
      create_component(linkslist.$$.fragment);
      t = space();
      create_component(cardslist.$$.fragment);
    },
    m(target, anchor) {
      mount_component(linkslist, target, anchor);
      insert(target, t, anchor);
      mount_component(cardslist, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      var _a2;
      const linkslist_changes = {};
      if (dirty & /*$tabs*/
      8)
        linkslist_changes.tabs = /*$tabs*/
        ctx2[3];
      if (dirty & /*selectedTabIndex*/
      1)
        linkslist_changes.selectedTabIndex = /*selectedTabIndex*/
        ctx2[0];
      linkslist.$set(linkslist_changes);
      const cardslist_changes = {};
      if (dirty & /*$tabs, selectedTabIndex*/
      9)
        cardslist_changes.cards = /*$tabs*/
        (_a2 = ctx2[3][
          /*selectedTabIndex*/
          ctx2[0]
        ]) == null ? void 0 : _a2.cards;
      cardslist.$set(cardslist_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(linkslist.$$.fragment, local);
      transition_in(cardslist.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(linkslist.$$.fragment, local);
      transition_out(cardslist.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(t);
      }
      destroy_component(linkslist, detaching);
      destroy_component(cardslist, detaching);
    }
  };
}
function create_if_block_3(ctx) {
  let drawer;
  let div;
  let __color_accent_last;
  let current;
  drawer = new Drawer({
    props: {
      title: "Settings",
      $$slots: { default: [create_default_slot_3] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      div = element("div");
      create_component(drawer.$$.fragment);
      set_style(div, "display", "contents");
      set_style(div, "--color-accent", __color_accent_last = /*$settings*/
      ctx[4].color);
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(drawer, div, null);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty & /*$settings*/
      16 && __color_accent_last !== (__color_accent_last = /*$settings*/
      ctx2[4].color)) {
        set_style(div, "--color-accent", __color_accent_last);
      }
      const drawer_changes = {};
      if (dirty & /*$$scope*/
      4096) {
        drawer_changes.$$scope = { dirty, ctx: ctx2 };
      }
      drawer.$set(drawer_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(drawer.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(drawer.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching && drawer)
        detach(div);
      destroy_component(drawer, detaching);
    }
  };
}
function create_if_block_2(ctx) {
  let drawer;
  let div;
  let __color_accent_last;
  let current;
  drawer = new Drawer({
    props: {
      title: "Update Card",
      $$slots: { default: [create_default_slot_2] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      div = element("div");
      create_component(drawer.$$.fragment);
      set_style(div, "display", "contents");
      set_style(div, "--color-accent", __color_accent_last = /*$settings*/
      ctx[4].color);
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(drawer, div, null);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty & /*$settings*/
      16 && __color_accent_last !== (__color_accent_last = /*$settings*/
      ctx2[4].color)) {
        set_style(div, "--color-accent", __color_accent_last);
      }
      const drawer_changes = {};
      if (dirty & /*$$scope, $tabs, selectedTabIndex, selectedCardIndex*/
      4107) {
        drawer_changes.$$scope = { dirty, ctx: ctx2 };
      }
      drawer.$set(drawer_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(drawer.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(drawer.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching && drawer)
        detach(div);
      destroy_component(drawer, detaching);
    }
  };
}
function create_if_block_1(ctx) {
  let drawer;
  let div;
  let __color_accent_last;
  let current;
  drawer = new Drawer({
    props: {
      title: "Manage Tabs",
      $$slots: { default: [create_default_slot_1] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      div = element("div");
      create_component(drawer.$$.fragment);
      set_style(div, "display", "contents");
      set_style(div, "--color-accent", __color_accent_last = /*$settings*/
      ctx[4].color);
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(drawer, div, null);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty & /*$settings*/
      16 && __color_accent_last !== (__color_accent_last = /*$settings*/
      ctx2[4].color)) {
        set_style(div, "--color-accent", __color_accent_last);
      }
      const drawer_changes = {};
      if (dirty & /*$$scope*/
      4096) {
        drawer_changes.$$scope = { dirty, ctx: ctx2 };
      }
      drawer.$set(drawer_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(drawer.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(drawer.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching && drawer)
        detach(div);
      destroy_component(drawer, detaching);
    }
  };
}
function create_if_block(ctx) {
  let drawer;
  let div;
  let __color_accent_last;
  let current;
  drawer = new Drawer({
    props: {
      title: "Update Tab",
      $$slots: { default: [create_default_slot] },
      $$scope: { ctx }
    }
  });
  return {
    c() {
      div = element("div");
      create_component(drawer.$$.fragment);
      set_style(div, "display", "contents");
      set_style(div, "--color-accent", __color_accent_last = /*$settings*/
      ctx[4].color);
    },
    m(target, anchor) {
      insert(target, div, anchor);
      mount_component(drawer, div, null);
      current = true;
    },
    p(ctx2, dirty) {
      if (dirty & /*$settings*/
      16 && __color_accent_last !== (__color_accent_last = /*$settings*/
      ctx2[4].color)) {
        set_style(div, "--color-accent", __color_accent_last);
      }
      const drawer_changes = {};
      if (dirty & /*$$scope, selectedTabIndex*/
      4097) {
        drawer_changes.$$scope = { dirty, ctx: ctx2 };
      }
      drawer.$set(drawer_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(drawer.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(drawer.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      if (detaching && drawer)
        detach(div);
      destroy_component(drawer, detaching);
    }
  };
}
function create_default_slot_3(ctx) {
  let settingsdrawer;
  let current;
  settingsdrawer = new SettingsDrawer({ props: { tabs: (
    /*tabs*/
    ctx[7]
  ) } });
  return {
    c() {
      create_component(settingsdrawer.$$.fragment);
    },
    m(target, anchor) {
      mount_component(settingsdrawer, target, anchor);
      current = true;
    },
    p: noop,
    i(local) {
      if (current)
        return;
      transition_in(settingsdrawer.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(settingsdrawer.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(settingsdrawer, detaching);
    }
  };
}
function create_default_slot_2(ctx) {
  let updatecarddrawer;
  let current;
  updatecarddrawer = new UpdateCardDrawer({
    props: {
      card: (
        /*$tabs*/
        ctx[3][
          /*selectedTabIndex*/
          ctx[0]
        ].cards[
          /*selectedCardIndex*/
          ctx[1]
        ]
      ),
      onSave: (
        /*handleSaveCard*/
        ctx[10]
      )
    }
  });
  return {
    c() {
      create_component(updatecarddrawer.$$.fragment);
    },
    m(target, anchor) {
      mount_component(updatecarddrawer, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const updatecarddrawer_changes = {};
      if (dirty & /*$tabs, selectedTabIndex, selectedCardIndex*/
      11)
        updatecarddrawer_changes.card = /*$tabs*/
        ctx2[3][
          /*selectedTabIndex*/
          ctx2[0]
        ].cards[
          /*selectedCardIndex*/
          ctx2[1]
        ];
      updatecarddrawer.$set(updatecarddrawer_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(updatecarddrawer.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(updatecarddrawer.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(updatecarddrawer, detaching);
    }
  };
}
function create_default_slot_1(ctx) {
  let managetabsdrawer;
  let current;
  managetabsdrawer = new ManageTabsDrawer({ props: { tabs: (
    /*tabs*/
    ctx[7]
  ) } });
  return {
    c() {
      create_component(managetabsdrawer.$$.fragment);
    },
    m(target, anchor) {
      mount_component(managetabsdrawer, target, anchor);
      current = true;
    },
    p: noop,
    i(local) {
      if (current)
        return;
      transition_in(managetabsdrawer.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(managetabsdrawer.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(managetabsdrawer, detaching);
    }
  };
}
function create_default_slot(ctx) {
  let updategriddrawer;
  let current;
  updategriddrawer = new UpdateGridDrawer({
    props: {
      tabs: (
        /*tabs*/
        ctx[7]
      ),
      selectedTabIndex: (
        /*selectedTabIndex*/
        ctx[0]
      )
    }
  });
  return {
    c() {
      create_component(updategriddrawer.$$.fragment);
    },
    m(target, anchor) {
      mount_component(updategriddrawer, target, anchor);
      current = true;
    },
    p(ctx2, dirty) {
      const updategriddrawer_changes = {};
      if (dirty & /*selectedTabIndex*/
      1)
        updategriddrawer_changes.selectedTabIndex = /*selectedTabIndex*/
        ctx2[0];
      updategriddrawer.$set(updategriddrawer_changes);
    },
    i(local) {
      if (current)
        return;
      transition_in(updategriddrawer.$$.fragment, local);
      current = true;
    },
    o(local) {
      transition_out(updategriddrawer.$$.fragment, local);
      current = false;
    },
    d(detaching) {
      destroy_component(updategriddrawer, detaching);
    }
  };
}
function create_fragment(ctx) {
  let main;
  let appheader;
  let t0;
  let navbar;
  let t1;
  let main_inert_value;
  let main_style_value;
  let t2;
  let current_block_type_index;
  let if_block1;
  let if_block1_anchor;
  let current;
  appheader = new AppHeader({});
  navbar = new NavBar({
    props: {
      tabs: (
        /*$tabs*/
        ctx[3]
      ),
      selectedTabIndex: (
        /*selectedTabIndex*/
        ctx[0]
      ),
      onChangeTab: (
        /*handleChangeTab*/
        ctx[8]
      ),
      onEditTabs: (
        /*handleEditTabs*/
        ctx[11]
      )
    }
  });
  let if_block0 = (
    /*$tabs*/
    ctx[3].length && create_if_block_4(ctx)
  );
  const if_block_creators = [create_if_block, create_if_block_1, create_if_block_2, create_if_block_3];
  const if_blocks = [];
  function select_block_type(ctx2, dirty) {
    if (
      /*$layerConfig*/
      ctx2[2].subtype === "grid"
    )
      return 0;
    if (
      /*$layerConfig*/
      ctx2[2].subtype === "tab"
    )
      return 1;
    if (
      /*$layerConfig*/
      ctx2[2].subtype === "card"
    )
      return 2;
    if (
      /*$layerConfig*/
      ctx2[2].subtype === "setting"
    )
      return 3;
    return -1;
  }
  if (~(current_block_type_index = select_block_type(ctx))) {
    if_block1 = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
  }
  return {
    c() {
      main = element("main");
      create_component(appheader.$$.fragment);
      t0 = space();
      create_component(navbar.$$.fragment);
      t1 = space();
      if (if_block0)
        if_block0.c();
      t2 = space();
      if (if_block1)
        if_block1.c();
      if_block1_anchor = empty();
      main.inert = main_inert_value = /*$layerConfig*/
      ctx[2].activate;
      attr(main, "style", main_style_value = `--color-accent: ${/*$settings*/
      ctx[4].color}`);
    },
    m(target, anchor) {
      insert(target, main, anchor);
      mount_component(appheader, main, null);
      append(main, t0);
      mount_component(navbar, main, null);
      append(main, t1);
      if (if_block0)
        if_block0.m(main, null);
      insert(target, t2, anchor);
      if (~current_block_type_index) {
        if_blocks[current_block_type_index].m(target, anchor);
      }
      insert(target, if_block1_anchor, anchor);
      current = true;
    },
    p(ctx2, [dirty]) {
      const navbar_changes = {};
      if (dirty & /*$tabs*/
      8)
        navbar_changes.tabs = /*$tabs*/
        ctx2[3];
      if (dirty & /*selectedTabIndex*/
      1)
        navbar_changes.selectedTabIndex = /*selectedTabIndex*/
        ctx2[0];
      navbar.$set(navbar_changes);
      if (
        /*$tabs*/
        ctx2[3].length
      ) {
        if (if_block0) {
          if_block0.p(ctx2, dirty);
          if (dirty & /*$tabs*/
          8) {
            transition_in(if_block0, 1);
          }
        } else {
          if_block0 = create_if_block_4(ctx2);
          if_block0.c();
          transition_in(if_block0, 1);
          if_block0.m(main, null);
        }
      } else if (if_block0) {
        group_outros();
        transition_out(if_block0, 1, 1, () => {
          if_block0 = null;
        });
        check_outros();
      }
      if (!current || dirty & /*$layerConfig*/
      4 && main_inert_value !== (main_inert_value = /*$layerConfig*/
      ctx2[2].activate)) {
        main.inert = main_inert_value;
      }
      if (!current || dirty & /*$settings*/
      16 && main_style_value !== (main_style_value = `--color-accent: ${/*$settings*/
      ctx2[4].color}`)) {
        attr(main, "style", main_style_value);
      }
      let previous_block_index = current_block_type_index;
      current_block_type_index = select_block_type(ctx2);
      if (current_block_type_index === previous_block_index) {
        if (~current_block_type_index) {
          if_blocks[current_block_type_index].p(ctx2, dirty);
        }
      } else {
        if (if_block1) {
          group_outros();
          transition_out(if_blocks[previous_block_index], 1, 1, () => {
            if_blocks[previous_block_index] = null;
          });
          check_outros();
        }
        if (~current_block_type_index) {
          if_block1 = if_blocks[current_block_type_index];
          if (!if_block1) {
            if_block1 = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx2);
            if_block1.c();
          } else {
            if_block1.p(ctx2, dirty);
          }
          transition_in(if_block1, 1);
          if_block1.m(if_block1_anchor.parentNode, if_block1_anchor);
        } else {
          if_block1 = null;
        }
      }
    },
    i(local) {
      if (current)
        return;
      transition_in(appheader.$$.fragment, local);
      transition_in(navbar.$$.fragment, local);
      transition_in(if_block0);
      transition_in(if_block1);
      current = true;
    },
    o(local) {
      transition_out(appheader.$$.fragment, local);
      transition_out(navbar.$$.fragment, local);
      transition_out(if_block0);
      transition_out(if_block1);
      current = false;
    },
    d(detaching) {
      if (detaching) {
        detach(main);
        detach(t2);
        detach(if_block1_anchor);
      }
      destroy_component(appheader);
      destroy_component(navbar);
      if (if_block0)
        if_block0.d();
      if (~current_block_type_index) {
        if_blocks[current_block_type_index].d(detaching);
      }
    }
  };
}
function instance($$self, $$props, $$invalidate) {
  let $layerConfig;
  let $tabs;
  let $settings;
  setLayerConfig();
  setSettings();
  let layerConfig = getLayerConfig();
  component_subscribe($$self, layerConfig, (value) => $$invalidate(2, $layerConfig = value));
  let settings = getSettings();
  component_subscribe($$self, settings, (value) => $$invalidate(4, $settings = value));
  let tabs = writable([]);
  component_subscribe($$self, tabs, (value) => $$invalidate(3, $tabs = value));
  let selectedTabIndex = $settings.defaultTab;
  let selectedCardIndex = 0;
  onMount(() => {
    const appContent = localStorage.getItem("appContent") ?? "[]";
    if (appContent) {
      set_store_value(tabs, $tabs = JSON.parse(appContent), $tabs);
    }
  });
  function handleChangeTab(tabIndex) {
    $$invalidate(0, selectedTabIndex = tabIndex);
  }
  function handleChangeCard(cardIndex) {
    $$invalidate(1, selectedCardIndex = cardIndex);
  }
  function handleSaveCard(card) {
    const cardsUpdate = [
      ...$tabs[selectedTabIndex].cards.slice(0, selectedCardIndex),
      card,
      ...$tabs[selectedTabIndex].cards.slice(selectedCardIndex + 1)
    ];
    const tabUpdate = {
      ...$tabs[selectedTabIndex],
      cards: [...cardsUpdate]
    };
    const newAppState = [
      ...$tabs.slice(0, selectedTabIndex),
      tabUpdate,
      ...$tabs.slice(selectedTabIndex + 1)
    ];
    set_store_value(tabs, $tabs = newAppState, $tabs);
    localStorage.setItem("appContent", JSON.stringify(newAppState));
  }
  function handleEditTabs() {
    set_store_value(
      layerConfig,
      $layerConfig = {
        activate: true,
        type: "drawer",
        subtype: "tab"
      },
      $layerConfig
    );
  }
  return [
    selectedTabIndex,
    selectedCardIndex,
    $layerConfig,
    $tabs,
    $settings,
    layerConfig,
    settings,
    tabs,
    handleChangeTab,
    handleChangeCard,
    handleSaveCard,
    handleEditTabs
  ];
}
class App extends SvelteComponent {
  constructor(options) {
    super();
    init(this, options, instance, create_fragment, safe_not_equal, {});
  }
}
const global = "";
const variables = "";
new App({
  // @ts-expect-error
  target: document.getElementById("app")
});
//# sourceMappingURL=index-75be0793.js.map
